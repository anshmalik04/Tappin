import pkg from 'pg';
const { Client } = pkg;
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { randomUUID } from 'crypto';

const s3Client = new S3Client({ region: 'us-east-1' });
const BUCKET = process.env.S3_BUCKET;

export const handler = async (event) => {
  const db = new Client({
    host: process.env.DB_HOST,
    port: 5432,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    ssl: { rejectUnauthorized: false }
  });

  try {
    const userId = event.requestContext.authorizer.jwt.claims.sub;
    const body = JSON.parse(event.body);
    const { order_index, is_primary, content_type } = body;

    if (order_index === undefined || !content_type) {
      return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'order_index and content_type are required' }) };
    }

    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(content_type)) {
      return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'content_type must be image/jpeg, image/png, or image/webp' }) };
    }

    await db.connect();

    const photoCount = await db.query(`SELECT COUNT(*) as count FROM user_photos WHERE user_id = $1`, [userId]);
    if (parseInt(photoCount.rows[0].count) >= 6) {
      await db.end();
      return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Maximum of 6 photos allowed' }) };
    }

    const fileKey = `users/${userId}/${randomUUID()}.jpg`;
    const command = new PutObjectCommand({ Bucket: BUCKET, Key: fileKey, ContentType: content_type });
    const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 300 });
    const photoUrl = `https://${BUCKET}.s3.us-east-1.amazonaws.com/${fileKey}`;

    if (is_primary) {
      await db.query(`UPDATE user_photos SET is_primary = false WHERE user_id = $1`, [userId]);
    }

    const photo = await db.query(
      `INSERT INTO user_photos (user_id, photo_url, order_index, is_primary) VALUES ($1, $2, $3, $4) ON CONFLICT (user_id, order_index) DO UPDATE SET photo_url = $2, is_primary = $4 RETURNING id, photo_url, order_index, is_primary`,
      [userId, photoUrl, order_index, is_primary || false]
    );

    await db.end();
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ upload_url: uploadUrl, photo: photo.rows[0], expires_in: 300 }) };

  } catch (error) {
    console.error('uploadPhoto error:', error);
    try { await db.end(); } catch(e) {}
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Internal server error' }) };
  }
};