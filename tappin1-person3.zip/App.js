import 'react-native-gesture-handler';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import PhoneScreen from './src/screens/auth/PhoneScreen';
import OTPScreen from './src/screens/auth/OTPScreen';
import ProfileSetupScreen from './src/screens/auth/ProfileSetupScreen';
import SplashScreen from './src/screens/SplashScreen';
import OnboardingScreen from './src/screens/OnboardingScreen';
import MapScreen from './src/screens/MapScreen';
import TonightScreen from './src/screens/TonightScreen';
import ChatScreen from './src/screens/ChatScreen';
import MeScreen from './src/screens/MeScreen';
import VenueCardScreen from './src/screens/VenueCardScreen';
import ProfileViewScreen from './src/screens/ProfileViewScreen';
import MatchConfirmationScreen from './src/screens/MatchConfirmationScreen';
import MatchesScreen from './src/screens/MatchesScreen';
import EmergencyContactsScreen from './src/screens/EmergencyContactsScreen';
import MyProfileScreen from './src/screens/MyProfileScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function MainApp() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarLabelStyle: { fontSize: 11 },
      }}
    >
      <Tab.Screen name="Map" component={MapScreen} />
      <Tab.Screen name="Tonight" component={TonightScreen} />
      <Tab.Screen name="Matches" component={MatchesScreen} />
      <Tab.Screen name="Me" component={MyProfileScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Phone" component={PhoneScreen} />
        <Stack.Screen name="OTP" component={OTPScreen} />
        <Stack.Screen name="ProfileSetup" component={ProfileSetupScreen} />
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        <Stack.Screen name="MainApp" component={MainApp} />
        <Stack.Screen name="VenueCard" component={VenueCardScreen} />
        <Stack.Screen name="ProfileView" component={ProfileViewScreen} />
        <Stack.Screen name="MatchConfirmation" component={MatchConfirmationScreen} />
        <Stack.Screen name="Chat" component={ChatScreen} />
        <Stack.Screen name="EmergencyContacts" component={EmergencyContactsScreen} />
        <Stack.Screen name="MyProfile" component={MyProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}