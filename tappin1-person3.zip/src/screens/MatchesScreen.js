import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, Image, ScrollView, ActivityIndicator, RefreshControl
} from 'react-native';
import { getMatches } from '../services/api';
import { getCurrentUser } from '../services/auth';

export default function MatchesScreen({ navigation }) {
  const [matches, setMatches] = useState([]);
  const [tappedInOnMe, setTappedInOnMe] = useState([]);
  const [isPro, setIsPro] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [me, data] = await Promise.all([
        getCurrentUser(),
        getMatches()
      ]);
      setIsPro(me?.is_pro || false);
      setMatches(data?.matches || []);
      setTappedInOnMe(data?.tapped_in_on_me || []);
    } catch (e) {
      console.error('Failed to load matches:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const renderMatch = ({ item }) => (
    <TouchableOpacity
      style={styles.matchRow}
      onPress={() => navigation.navigate('Chat', { match: item })}
    >
      <View style={styles.photoContainer}>
        <Image source={{ uri: item.photo }} style={styles.photo} />
        {item.unread && <View style={styles.unreadDot} />}
      </View>
      <View style={styles.matchInfo}>
        <View style={styles.matchTopRow}>
          <Text style={styles.matchName}>{item.name}</Text>
          <Text style={styles.matchTimestamp}>{item.timestamp}</Text>
        </View>
        <Text style={styles.matchVenue}>📍 {item.venue}</Text>
        <Text
          style={[styles.matchLastMessage, item.unread && styles.matchLastMessageUnread]}
          numberOfLines={1}
        >
          {item.lastMessage}
        </Text>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  return (
    <View style={styles.container}>

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Matches</Text>
      </View>

      {/* Pro: Tapped In on you */}
      {isPro ? (
        <View style={styles.tappedInSection}>
          <Text style={styles.tappedInHeading}>
            {tappedInOnMe.length} people Tapped In on you
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {tappedInOnMe.map(user => (
              <TouchableOpacity
                key={user.id}
                style={styles.tappedInUser}
                onPress={() => navigation.navigate('ProfileView', { user, venueId: user.venue_id })}
              >
                <Image source={{ uri: user.photo }} style={styles.tappedInPhoto} />
                <Text style={styles.tappedInName}>{user.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      ) : (
        tappedInOnMe.length > 0 && (
          <TouchableOpacity style={styles.proPrompt}>
            <Text style={styles.proPromptText}>
              🔒 {tappedInOnMe.length} people Tapped In on you —{' '}
              <Text style={styles.proPromptLink}>Upgrade to Pro to see</Text>
            </Text>
          </TouchableOpacity>
        )
      )}

      {/* Matches list */}
      {matches.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>No matches yet.</Text>
          <Text style={styles.emptyStateSubtext}>
            Check in to a venue and Tap In on someone.
          </Text>
        </View>
      ) : (
        <FlatList
          data={matches}
          keyExtractor={item => item.id}
          renderItem={renderMatch}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#2563eb" />}
        />
      )}

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: {
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: { fontSize: 28, fontWeight: '800', color: '#111' },
  tappedInSection: {
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  tappedInHeading: {
    fontSize: 13, fontWeight: '600', color: '#888',
    marginBottom: 12, textTransform: 'uppercase',
  },
  tappedInUser: { alignItems: 'center', marginRight: 16 },
  tappedInPhoto: {
    width: 56, height: 56, borderRadius: 28,
    borderWidth: 2, borderColor: '#2563eb',
  },
  tappedInName: { fontSize: 11, color: '#444', marginTop: 4 },
  proPrompt: {
    backgroundColor: '#eff6ff', paddingVertical: 12, paddingHorizontal: 20,
    borderBottomWidth: 1, borderBottomColor: '#dbeafe',
  },
  proPromptText: { fontSize: 13, color: '#444' },
  proPromptLink: { color: '#2563eb', fontWeight: '700' },
  list: { paddingVertical: 8 },
  matchRow: {
    flexDirection: 'row', paddingHorizontal: 20, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: '#f0f0f0', alignItems: 'center',
  },
  photoContainer: { position: 'relative', marginRight: 14 },
  photo: { width: 56, height: 56, borderRadius: 28 },
  unreadDot: {
    position: 'absolute', top: 0, right: 0,
    width: 14, height: 14, borderRadius: 7,
    backgroundColor: '#2563eb', borderWidth: 2, borderColor: '#fff',
  },
  matchInfo: { flex: 1 },
  matchTopRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 2 },
  matchName: { fontSize: 16, fontWeight: '700', color: '#111' },
  matchTimestamp: { fontSize: 12, color: '#aaa' },
  matchVenue: { fontSize: 12, color: '#888', marginBottom: 3 },
  matchLastMessage: { fontSize: 14, color: '#888' },
  matchLastMessageUnread: { color: '#111', fontWeight: '600' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  emptyStateText: { fontSize: 18, fontWeight: '700', color: '#111', marginBottom: 8 },
  emptyStateSubtext: { fontSize: 14, color: '#888', textAlign: 'center', lineHeight: 20 },
});