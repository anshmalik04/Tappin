import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  TextInput, Modal, ScrollView, ActivityIndicator
} from 'react-native';
import { getEmergencyContacts, createEmergencyContact } from '../services/api';

const formatPhone = (text) => {
  const cleaned = text.replace(/\D/g, '');
  if (cleaned.length >= 6) {
    return `(${cleaned.slice(0,3)}) ${cleaned.slice(3,6)}-${cleaned.slice(6,10)}`;
  } else if (cleaned.length >= 3) {
    return `(${cleaned.slice(0,3)}) ${cleaned.slice(3)}`;
  }
  return cleaned;
};

export default function EmergencyContactsScreen({ navigation }) {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getEmergencyContacts()
      .then(data => setContacts(data || []))
      .catch(e => console.error('Failed to load contacts:', e))
      .finally(() => setLoading(false));
  }, []);

  const addContact = async () => {
    if (!newName.trim() || !newPhone.trim()) return;
    setSaving(true);
    try {
      const saved = await createEmergencyContact(newName.trim(), newPhone.trim());
      setContacts(prev => [...prev, saved]);
      setNewName('');
      setNewPhone('');
      setShowModal(false);
    } catch (e) {
      console.error('Failed to save contact:', e);
    } finally {
      setSaving(false);
    }
  };

  const removeContact = (id) => {
    setContacts(prev => prev.filter(c => c.id !== id));
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backBtn}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Emergency Contacts</Text>
        <View style={{ width: 32 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.explainerBox}>
          <Text style={styles.explainerText}>
            🛡 These people receive a text when you share a meetup spot in chat. Add up to 3 contacts.
          </Text>
        </View>

        {contacts.map(contact => (
          <View key={contact.id} style={styles.contactRow}>
            <View style={styles.contactAvatar}>
              <Text style={styles.contactAvatarText}>
                {contact.name.charAt(0).toUpperCase()}
              </Text>
            </View>
            <View style={styles.contactInfo}>
              <Text style={styles.contactName}>{contact.name}</Text>
              <Text style={styles.contactPhone}>{contact.phone}</Text>
            </View>
            <TouchableOpacity style={styles.removeBtn} onPress={() => removeContact(contact.id)}>
              <Text style={styles.removeBtnText}>Remove</Text>
            </TouchableOpacity>
          </View>
        ))}

        {contacts.length < 3 && (
          <TouchableOpacity style={styles.addBtn} onPress={() => setShowModal(true)}>
            <Text style={styles.addBtnText}>+ Add contact</Text>
          </TouchableOpacity>
        )}

        {contacts.length === 3 && (
          <Text style={styles.maxText}>Maximum of 3 contacts reached.</Text>
        )}
      </ScrollView>

      <Modal visible={showModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Add emergency contact</Text>

            <Text style={styles.inputLabel}>Name</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. Mom, Best Friend"
              placeholderTextColor="#aaa"
              value={newName}
              onChangeText={setNewName}
            />

            <Text style={styles.inputLabel}>Phone number</Text>
            <TextInput
              style={styles.input}
              placeholder="(215) 555-0100"
              placeholderTextColor="#aaa"
              value={newPhone}
              onChangeText={(text) => setNewPhone(formatPhone(text))}
              keyboardType="phone-pad"
            />

            <TouchableOpacity style={styles.saveBtn} onPress={addContact} disabled={saving}>
                {saving
                    ? <ActivityIndicator color="#fff" />
                    : <Text style={styles.saveBtnText}>Save contact</Text>
                }
            </TouchableOpacity>
              

            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowModal(false)}>
              <Text style={styles.cancelBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  backBtn: { fontSize: 24, color: '#2563eb' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#111' },
  content: { padding: 20 },
  explainerBox: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  explainerText: { fontSize: 14, color: '#1e40af', lineHeight: 20 },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  contactAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#2563eb',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  contactAvatarText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  contactInfo: { flex: 1 },
  contactName: { fontSize: 16, fontWeight: '600', color: '#111' },
  contactPhone: { fontSize: 13, color: '#888', marginTop: 2 },
  removeBtn: { paddingHorizontal: 12, paddingVertical: 6 },
  removeBtnText: { color: '#ef4444', fontSize: 14, fontWeight: '600' },
  addBtn: {
    marginTop: 20,
    borderWidth: 2,
    borderColor: '#2563eb',
    borderStyle: 'dashed',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  addBtnText: { color: '#2563eb', fontSize: 16, fontWeight: '700' },
  maxText: { marginTop: 20, textAlign: 'center', color: '#888', fontSize: 14 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  modalSheet: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
    paddingBottom: 40,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#888',
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  input: {
    backgroundColor: '#f1f5f9',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: '#111',
    marginBottom: 16,
  },
  saveBtn: {
    backgroundColor: '#2563eb',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 4,
  },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  cancelBtn: { paddingVertical: 14, alignItems: 'center' },
  cancelBtnText: { color: '#888', fontSize: 15, fontWeight: '600' },
});