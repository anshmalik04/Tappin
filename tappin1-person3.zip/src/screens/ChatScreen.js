import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput,
  TouchableOpacity, KeyboardAvoidingView, Platform,
  Modal, SafeAreaView, ActivityIndicator
} from 'react-native';
import { getMessages, sendMessage } from '../services/api';

export default function ChatScreen({ navigation, route }) {
  const { match } = route.params;
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showMeetupModal, setShowMeetupModal] = useState(false);
  const [showSafetySheet, setShowSafetySheet] = useState(false);
  const flatListRef = useRef(null);
  const MEETUP_SPOTS = ['Main floor', 'Bar area', 'DJ Stage', 'Rooftop', 'Entrance', 'Other'];

  useEffect(() => {
    loadMessages();
  }, []);

  const loadMessages = async () => {
    try {
      const data = await getMessages(match.id);
      setMessages(data || []);
    } catch (e) {
      console.error('Failed to load messages:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!inputText.trim()) return;
    const text = inputText.trim();
    setInputText('');
    setSending(true);
    try {
      const msg = await sendMessage(match.id, text, null);
      setMessages(prev => [...prev, msg]);
      flatListRef.current?.scrollToEnd({ animated: true });
    } catch (e) {
      console.error('Send failed:', e);
    } finally {
      setSending(false);
    }
  };

  const handleMeetupSpot = async (spot) => {
    setShowMeetupModal(false);
    setSending(true);
    try {
      const msg = await sendMessage(match.id, `📍 Meetup spot: ${spot}`, spot);
      setMessages(prev => [...prev, msg]);
      flatListRef.current?.scrollToEnd({ animated: true });
    } catch (e) {
      console.error('Meetup send failed:', e);
    } finally {
      setSending(false);
    }
  };

  const renderMessage = ({ item }) => {
    const isMe = item.sender_id === match.my_id;
    return (
      <View style={[styles.bubble, isMe ? styles.myBubble : styles.theirBubble]}>
        <Text style={[styles.bubbleText, isMe ? styles.myText : styles.theirText]}>
          {item.content}
        </Text>
        <Text style={styles.timestamp}>
          {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerName}>{match.other_user?.name}</Text>
        <TouchableOpacity onPress={() => setShowSafetySheet(true)}>
          <Text style={styles.safetyIcon}>🛡</Text>
        </TouchableOpacity>
      </View>

      {/* Messages */}
      {loading ? (
        <ActivityIndicator style={{ flex: 1 }} color="#2563eb" />
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={item => item.id?.toString()}
          renderItem={renderMessage}
          contentContainerStyle={styles.messageList}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
        />
      )}

      {/* Input Bar */}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.inputBar}>
          <TouchableOpacity onPress={() => setShowMeetupModal(true)} style={styles.pinBtn}>
            <Text style={styles.pinIcon}>📍</Text>
          </TouchableOpacity>
          <TextInput
            style={styles.input}
            value={inputText}
            onChangeText={setInputText}
            placeholder="Message..."
            placeholderTextColor="#aaa"
            multiline
          />
          <TouchableOpacity
            style={[styles.sendBtn, !inputText.trim() && styles.sendBtnDisabled]}
            onPress={handleSend}
            disabled={!inputText.trim() || sending}
          >
            <Text style={styles.sendText}>↑</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      {/* Meetup Spot Modal */}
      <Modal visible={showMeetupModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Choose a meetup spot</Text>
            {MEETUP_SPOTS.map(spot => (
              <TouchableOpacity key={spot} style={styles.spotRow} onPress={() => handleMeetupSpot(spot)}>
                <Text style={styles.spotText}>{spot}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowMeetupModal(false)}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Safety Sheet */}
      <Modal visible={showSafetySheet} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Safety</Text>
            {['Share my location', 'Call 911', 'End conversation'].map(opt => (
              <TouchableOpacity key={opt} style={styles.spotRow} onPress={() => setShowSafetySheet(false)}>
                <Text style={[styles.spotText, opt === 'Call 911' && { color: '#ef4444' }]}>{opt}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowSafetySheet(false)}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  back: { fontSize: 24, color: '#2563eb' },
  headerName: { fontSize: 17, fontWeight: '700', color: '#111' },
  safetyIcon: { fontSize: 22 },
  messageList: { padding: 16, gap: 8 },
  bubble: { maxWidth: '75%', borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10, marginBottom: 4 },
  myBubble: { alignSelf: 'flex-end', backgroundColor: '#2563eb' },
  theirBubble: { alignSelf: 'flex-start', backgroundColor: '#f3f4f6' },
  bubbleText: { fontSize: 15 },
  myText: { color: '#fff' },
  theirText: { color: '#111' },
  timestamp: { fontSize: 10, color: '#aaa', marginTop: 4, alignSelf: 'flex-end' },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 12, paddingVertical: 8, borderTopWidth: 1, borderTopColor: '#f0f0f0', gap: 8 },
  pinBtn: { paddingBottom: 8 },
  pinIcon: { fontSize: 22 },
  input: { flex: 1, backgroundColor: '#f3f4f6', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10, fontSize: 15, maxHeight: 100 },
  sendBtn: { backgroundColor: '#2563eb', width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  sendBtnDisabled: { backgroundColor: '#93c5fd' },
  sendText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 17, fontWeight: '700', color: '#111', marginBottom: 16, textAlign: 'center' },
  spotRow: { paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  spotText: { fontSize: 16, color: '#111', textAlign: 'center' },
  cancelBtn: { marginTop: 12, paddingVertical: 14, alignItems: 'center' },
  cancelText: { fontSize: 16, color: '#2563eb', fontWeight: '600' },
});