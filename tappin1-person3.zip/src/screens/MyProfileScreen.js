import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Image, Modal, TextInput, ActivityIndicator,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { getProfile, updateProfile, uploadPhoto } from '../services/api';
import { signOut } from '../services/auth';

export default function MyProfileScreen({ navigation }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showBioModal, setShowBioModal] = useState(false);
  const [showTagModal, setShowTagModal] = useState(false);
  const [showMusicModal, setShowMusicModal] = useState(false);
  const [editBio, setEditBio] = useState('');

  const ALL_TAGS = ['Social', 'Adventurous', 'Night owl', 'Chill', 'Foodie', 'Sporty', 'Creative', 'Traveler'];
  const ALL_MUSIC = ['House', 'R&B', 'Indie', 'Hip-hop', 'Pop', 'Jazz', 'Rock', 'EDM'];

  const loadProfile = () => {
    getProfile()
      .then(data => {
        setUser(data);
        setEditBio(data?.bio || '');
      })
      .catch(e => console.error('Failed to load profile:', e))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadProfile();
  }, []);

  const saveBio = async () => {
    try {
      await updateProfile({ bio: editBio });
      setUser(prev => ({ ...prev, bio: editBio }));
      setShowBioModal(false);
    } catch (e) {
      console.error('Failed to save bio:', e);
    }
  };

  const toggleTag = async (tag, field) => {
    const current = user[field] || [];
    const updated = current.includes(tag)
      ? current.filter(t => t !== tag)
      : [...current, tag];
    setUser(prev => ({ ...prev, [field]: updated }));
    try {
      await updateProfile({ [field]: updated });
    } catch (e) {
      console.error('Failed to save tags:', e);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigation.reset({ index: 0, routes: [{ name: 'Phone' }] });
    } catch (e) {
      console.error('Sign out failed:', e);
    }
  };

  const handlePhotoUpload = async (orderIndex) => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Permission needed', 'Please allow photo access to upload photos.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (result.canceled) return;

      const asset = result.assets[0];
      const response = await uploadPhoto(orderIndex, orderIndex === 0, 'image/jpeg');

      await fetch(response.upload_url, {
        method: 'PUT',
        headers: { 'Content-Type': 'image/jpeg' },
        body: { uri: asset.uri },
      });

      Alert.alert('Success', 'Photo uploaded!');
      loadProfile();
    } catch (err) {
      Alert.alert('Error', 'Failed to upload photo. Please try again.');
      console.error('Photo upload error:', err);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>

        <View style={styles.header}>
          <Text style={styles.headerTitle}>My Profile</Text>
        </View>

        <View style={styles.photoSection}>
          <View style={styles.primaryPhotoContainer}>
            <Image source={{ uri: user.photos[0] }} style={styles.primaryPhoto} />
            <TouchableOpacity style={styles.cameraOverlay} onPress={() => handlePhotoUpload(0)}>
              <Text style={styles.cameraIcon}>📷</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.userName}>{user.name}, {user.age}</Text>
          <View style={styles.badgeRow}>
            {user.is_verified && (
              <View style={styles.verifiedBadge}>
                <Text style={styles.verifiedText}>✓ VERIFIED</Text>
              </View>
            )}
            {user.is_pro && (
              <View style={styles.proBadge}>
                <Text style={styles.proText}>PRO</Text>
              </View>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Bio</Text>
            <TouchableOpacity onPress={() => { setEditBio(user.bio); setShowBioModal(true); }}>
              <Text style={styles.editBtn}>Edit</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.bioText}>{user.bio}</Text>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Vibe</Text>
            <TouchableOpacity onPress={() => setShowTagModal(true)}>
              <Text style={styles.editBtn}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.chips}>
            {user.personality_tags.map(tag => (
              <View key={tag} style={styles.chip}>
                <Text style={styles.chipText}>{tag}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Music</Text>
            <TouchableOpacity onPress={() => setShowMusicModal(true)}>
              <Text style={styles.editBtn}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.chips}>
            {user.music_taste.map(genre => (
              <View key={genre} style={styles.chip}>
                <Text style={styles.chipText}>{genre}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Photos</Text>
          <View style={styles.photoGrid}>
            {user.photos.map((photo, index) => (
              <TouchableOpacity key={index} style={styles.gridPhoto} onPress={() => handlePhotoUpload(index)}>
                <Image source={{ uri: photo }} style={styles.gridPhotoImg} />
              </TouchableOpacity>
            ))}
            {user.photos.length < 6 && (
              <TouchableOpacity style={styles.addPhotoBtn} onPress={() => handlePhotoUpload(user.photos.length)}>
                <Text style={styles.addPhotoBtnText}>+</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <TouchableOpacity
            style={styles.settingsRow}
            onPress={() => navigation.navigate('EmergencyContacts')}
          >
            <Text style={styles.settingsRowText}>🛡 Emergency contacts</Text>
            <Text style={styles.settingsArrow}>›</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingsRow}>
            <Text style={styles.settingsRowText}>🔒 Privacy settings</Text>
            <Text style={styles.settingsArrow}>›</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingsRow}>
            <Text style={styles.settingsRowText}>⭐ Upgrade to Pro</Text>
            <Text style={styles.settingsArrow}>›</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.signOutBtn} onPress={handleSignOut}>
          <Text style={styles.signOutText}>Sign out</Text>
        </TouchableOpacity>

      </ScrollView>

      <Modal visible={showBioModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Edit bio</Text>
            <TextInput
              style={styles.bioInput}
              value={editBio}
              onChangeText={setEditBio}
              multiline
              maxLength={150}
              placeholder="Tell people about yourself..."
              placeholderTextColor="#aaa"
            />
            <Text style={styles.charCount}>{editBio.length}/150</Text>
            <TouchableOpacity style={styles.saveBtn} onPress={saveBio}>
              <Text style={styles.saveBtnText}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowBioModal(false)}>
              <Text style={styles.cancelBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showTagModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Edit vibe tags</Text>
            <View style={styles.chips}>
              {ALL_TAGS.map(tag => (
                <TouchableOpacity
                  key={tag}
                  style={[styles.chip, user.personality_tags.includes(tag) && styles.chipSelected]}
                  onPress={() => toggleTag(tag, 'personality_tags')}
                >
                  <Text style={[styles.chipText, user.personality_tags.includes(tag) && styles.chipTextSelected]}>
                    {tag}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={styles.saveBtn} onPress={() => setShowTagModal(false)}>
              <Text style={styles.saveBtnText}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showMusicModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Edit music taste</Text>
            <View style={styles.chips}>
              {ALL_MUSIC.map(genre => (
                <TouchableOpacity
                  key={genre}
                  style={[styles.chip, user.music_taste.includes(genre) && styles.chipSelected]}
                  onPress={() => toggleTag(genre, 'music_taste')}
                >
                  <Text style={[styles.chipText, user.music_taste.includes(genre) && styles.chipTextSelected]}>
                    {genre}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={styles.saveBtn} onPress={() => setShowMusicModal(false)}>
              <Text style={styles.saveBtnText}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  scroll: { paddingBottom: 60 },
  header: {
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: { fontSize: 28, fontWeight: '800', color: '#111' },
  photoSection: { alignItems: 'center', paddingVertical: 24 },
  primaryPhotoContainer: { position: 'relative', marginBottom: 12 },
  primaryPhoto: { width: 100, height: 100, borderRadius: 50 },
  cameraOverlay: {
    position: 'absolute', bottom: 0, right: 0,
    backgroundColor: '#2563eb', borderRadius: 14,
    width: 28, height: 28, alignItems: 'center', justifyContent: 'center',
  },
  cameraIcon: { fontSize: 14 },
  userName: { fontSize: 22, fontWeight: '700', color: '#111', marginBottom: 6 },
  badgeRow: { flexDirection: 'row', gap: 8 },
  verifiedBadge: {
    backgroundColor: '#22c55e', borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  verifiedText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  proBadge: {
    backgroundColor: '#2563eb', borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  proText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  section: {
    paddingHorizontal: 20, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: '#f0f0f0',
  },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#111' },
  editBtn: { fontSize: 14, color: '#2563eb', fontWeight: '600' },
  bioText: { fontSize: 15, color: '#444', lineHeight: 22 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    backgroundColor: '#eff6ff', borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 6,
  },
  chipSelected: { backgroundColor: '#2563eb' },
  chipText: { color: '#2563eb', fontSize: 13, fontWeight: '500' },
  chipTextSelected: { color: '#fff' },
  photoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  gridPhoto: { width: 100, height: 100, borderRadius: 10, overflow: 'hidden' },
  gridPhotoImg: { width: '100%', height: '100%' },
  addPhotoBtn: {
    width: 100, height: 100, borderRadius: 10,
    borderWidth: 2, borderColor: '#2563eb', borderStyle: 'dashed',
    alignItems: 'center', justifyContent: 'center',
  },
  addPhotoBtnText: { fontSize: 32, color: '#2563eb' },
  settingsRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: '#f0f0f0',
  },
  settingsRowText: { fontSize: 15, color: '#111' },
  settingsArrow: { fontSize: 18, color: '#aaa' },
  signOutBtn: { margin: 20, paddingVertical: 16, alignItems: 'center' },
  signOutText: { color: '#ef4444', fontSize: 16, fontWeight: '600' },
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end',
  },
  modalSheet: {
    backgroundColor: '#fff', borderTopLeftRadius: 20,
    borderTopRightRadius: 20, padding: 24, paddingBottom: 40,
  },
  modalTitle: {
    fontSize: 18, fontWeight: '700', color: '#111',
    marginBottom: 16, textAlign: 'center',
  },
  bioInput: {
    backgroundColor: '#f1f5f9', borderRadius: 10,
    padding: 14, fontSize: 15, color: '#111',
    minHeight: 100, textAlignVertical: 'top', marginBottom: 8,
  },
  charCount: { fontSize: 12, color: '#aaa', textAlign: 'right', marginBottom: 16 },
  saveBtn: {
    backgroundColor: '#2563eb', borderRadius: 12,
    paddingVertical: 16, alignItems: 'center',
  },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  cancelBtn: { paddingVertical: 14, alignItems: 'center' },
  cancelBtnText: { color: '#888', fontSize: 15, fontWeight: '600' },
});