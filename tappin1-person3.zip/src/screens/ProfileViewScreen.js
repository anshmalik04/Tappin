import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Dimensions, Image, ActivityIndicator
} from 'react-native';
import { createTapIn } from '../services/api';
import { getCurrentUser } from '../services/auth';

const { width } = Dimensions.get('window');

export default function ProfileViewScreen({ navigation, route }) {
  const { user, venueId } = route.params;
  const [tappedIn, setTappedIn] = useState(false);
  const [tapInsLeft, setTapInsLeft] = useState(5);
  const [isPro, setIsPro] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getCurrentUser().then(me => {
      setIsPro(me?.is_pro || false);
      setTapInsLeft(me?.tap_ins_remaining ?? 5);
    }).catch(() => {});
  }, []);

  const handleTapIn = async () => {
    if (tapInsLeft <= 0 && !isPro) return;
    setLoading(true);
    try {
      const result = await createTapIn(user.id, venueId);
      setTappedIn(true);
      setTapInsLeft(prev => prev - 1);
      if (result.mutual) {
        navigation.navigate('MatchConfirmation', { user });
      }
    } catch (e) {
      console.error('Tap In failed:', e);
    } finally {
      setLoading(false);
    }
  };

  const handlePass = () => {
    navigation.goBack();
  };

  const handleSave = () => {
    console.log('Saved');
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>

        {/* Photo */}
        <View style={styles.photoContainer}>
          <Image
            source={{ uri: user.photos?.[0] }}
            style={styles.photo}
          />
          <View style={styles.gradient} />
        </View>

        {/* User Info */}
        <View style={styles.info}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>{user.name}, {user.age}</Text>
            {user.is_verified && (
              <Text style={styles.verified}>✓ VERIFIED</Text>
            )}
          </View>

          <Text style={styles.matchScore}>{user.match_score}% match</Text>
          <Text style={styles.bio}>{user.bio}</Text>

          {/* Personality Tags */}
          <Text style={styles.sectionLabel}>Vibe</Text>
          <View style={styles.chips}>
            {user.personality_tags.map(tag => (
              <View key={tag} style={styles.chip}>
                <Text style={styles.chipText}>{tag}</Text>
              </View>
            ))}
          </View>

          {/* Music Taste */}
          <Text style={styles.sectionLabel}>Music</Text>
          <View style={styles.chips}>
            {user.music_taste.map(genre => (
              <View key={genre} style={styles.chip}>
                <Text style={styles.chipText}>{genre}</Text>
              </View>
            ))}
          </View>
        </View>

      </ScrollView>

      {/* Action Buttons */}
      <View style={styles.actions}>

        {tapInsLeft <= 0 && !isPro ? (
          <Text style={styles.upgradeText}>Upgrade to Pro for more Tap Ins</Text>
        ) : (
          <Text style={styles.tapInsLeft}>{tapInsLeft} Tap Ins left tonight</Text>
        )}

        <View style={styles.buttons}>
          <TouchableOpacity style={styles.passBtn} onPress={handlePass}>
            <Text style={styles.passBtnText}>PASS</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.tapInBtn, (tappedIn || tapInsLeft <= 0) && styles.tapInBtnDisabled]}
            onPress={handleTapIn}
            disabled={tappedIn || tapInsLeft <= 0}
          >
            <Text style={styles.tapInBtnText}>
              {loading ? <ActivityIndicator color="#fff" /> : tappedIn ? 'Tapped In!' : 'TAP IN'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
            <Text style={styles.saveBtnText}>🔖</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  scroll: { paddingBottom: 160 },
  photoContainer: { width, height: 420, position: 'relative' },
  photo: { width: '100%', height: '100%' },
  gradient: {
    position: 'absolute', bottom: 0, left: 0, right: 0, height: 120,
    backgroundColor: 'rgba(0,0,0,0.35)'
  },
  info: { padding: 20 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 4 },
  name: { fontSize: 24, fontWeight: '700', color: '#111' },
  verified: { fontSize: 12, color: '#fff', backgroundColor: '#22c55e', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10 },
  matchScore: { fontSize: 28, fontWeight: '800', color: '#2563eb', marginBottom: 10 },
  bio: { fontSize: 15, color: '#444', marginBottom: 16, lineHeight: 22 },
  sectionLabel: { fontSize: 13, fontWeight: '600', color: '#888', marginBottom: 8, textTransform: 'uppercase' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  chip: { backgroundColor: '#eff6ff', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6 },
  chipText: { color: '#2563eb', fontSize: 13, fontWeight: '500' },
  actions: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: '#fff', paddingHorizontal: 20, paddingBottom: 36,
    paddingTop: 12, borderTopWidth: 1, borderTopColor: '#f0f0f0'
  },
  tapInsLeft: { textAlign: 'center', fontSize: 13, color: '#888', marginBottom: 10 },
  upgradeText: { textAlign: 'center', fontSize: 13, color: '#ef4444', marginBottom: 10 },
  buttons: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  passBtn: {
    flex: 1, backgroundColor: '#e5e7eb', borderRadius: 14,
    paddingVertical: 16, alignItems: 'center'
  },
  passBtnText: { fontWeight: '700', color: '#555', fontSize: 15 },
  tapInBtn: {
    flex: 2, backgroundColor: '#2563eb', borderRadius: 14,
    paddingVertical: 16, alignItems: 'center'
  },
  tapInBtnDisabled: { backgroundColor: '#93c5fd' },
  tapInBtnText: { fontWeight: '800', color: '#fff', fontSize: 16 },
  saveBtn: {
    flex: 1, backgroundColor: '#f9fafb', borderRadius: 14,
    paddingVertical: 16, alignItems: 'center',
    borderWidth: 1, borderColor: '#e5e7eb'
  },
  saveBtnText: { fontSize: 20 },
});