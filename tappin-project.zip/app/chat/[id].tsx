import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Modal,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors } from '@/constants/Colors';
import { users, chatThreads } from '@/data/mockData';

const MEETUP_SPOTS = [
  'DJ Set Area',
  'Main Bar',
  'Back Bar',
  'Upstairs Lounge',
  'Near Bathrooms',
  'Front Entrance',
  'Stairs / Stairwell',
  'Patio',
];

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const user = users.find((u) => u.id === id) ?? users[0];
  const thread = chatThreads[id ?? '1'] ?? chatThreads['1'];

  const [messages, setMessages] = useState(thread.messages);
  const [inputText, setInputText] = useState('');
  const [meetupSpot, setMeetupSpot] = useState(thread.meetupSpot ?? 'DJ Set Area');
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const sendMessage = () => {
    if (!inputText.trim()) return;
    setMessages((prev) => [
      ...prev,
      {
        id: `m${Date.now()}`,
        senderId: 'me',
        text: inputText.trim(),
        timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
      },
    ]);
    setInputText('');
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={0}
    >
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
        <View style={styles.avatarSmall}>
          <Text style={styles.avatarSmallText}>{user.initial}</Text>
        </View>
        <View style={styles.headerInfo}>
          <Text style={styles.headerName}>{user.name}</Text>
          <View style={styles.atVenueRow}>
            <View style={styles.greenDot} />
            <Text style={styles.atVenue}>At {user.currentVenue ?? 'a venue'}</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.safetyBtn}>
          <Text style={styles.safetyBtnText}>🛡 Safety</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        style={styles.messageList}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingBottom: 16,
          paddingTop: 8,
        }}
        ListHeaderComponent={
          <View>
            {/* Meetup spot card */}
            <View style={styles.meetupCard}>
              <Text style={styles.meetupTitle}>📍 MEET UP SPOT</Text>
              <TouchableOpacity
                style={styles.meetupDropdown}
                onPress={() => setDropdownOpen(true)}
              >
                <Text style={styles.meetupDropdownText}>{meetupSpot}</Text>
                <Text style={styles.dropdownArrow}>▾</Text>
              </TouchableOpacity>
              <Text style={styles.meetupNote}>Shared with your emergency contacts</Text>
            </View>

            {/* Safety banner */}
            <View style={styles.safetyBanner}>
              <Text style={styles.safetyBannerTitle}>✓ Emergency contacts notified of meetup</Text>
              <Text style={styles.safetyBannerSub}>
                Meeting at {meetupSpot} · {user.currentVenue ?? 'venue'}
              </Text>
            </View>
          </View>
        }
        renderItem={({ item }) => {
          const isMe = item.senderId === 'me';
          return (
            <View style={[styles.messageRow, isMe && styles.messageRowMe]}>
              <View style={[styles.bubble, isMe ? styles.bubbleMe : styles.bubbleThem]}>
                <Text style={[styles.bubbleText, isMe && styles.bubbleTextMe]}>
                  {item.text}
                </Text>
              </View>
              <Text style={styles.timestamp}>{item.timestamp}</Text>
            </View>
          );
        }}
      />

      {/* Input bar */}
      <View style={[styles.inputBar, { paddingBottom: insets.bottom + 8 }]}>
        <TouchableOpacity style={styles.locationPinBtn}>
          <Text style={styles.locationPin}>📍</Text>
        </TouchableOpacity>
        <TextInput
          style={styles.textInput}
          placeholder="Message..."
          placeholderTextColor={Colors.textMuted}
          value={inputText}
          onChangeText={setInputText}
          multiline
        />
        <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
          <Text style={styles.sendBtnText}>↑</Text>
        </TouchableOpacity>
      </View>

      {/* Dropdown modal */}
      <Modal
        visible={dropdownOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setDropdownOpen(false)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setDropdownOpen(false)}
        >
          <View style={styles.dropdownMenu}>
            <Text style={styles.dropdownMenuTitle}>Choose Meetup Spot</Text>
            {MEETUP_SPOTS.map((spot) => (
              <TouchableOpacity
                key={spot}
                style={[styles.dropdownItem, meetupSpot === spot && styles.dropdownItemActive]}
                onPress={() => {
                  setMeetupSpot(spot);
                  setDropdownOpen(false);
                }}
              >
                <Text
                  style={[styles.dropdownItemText, meetupSpot === spot && styles.dropdownItemTextActive]}
                >
                  {spot}
                </Text>
                {meetupSpot === spot && <Text style={styles.checkmark}>✓</Text>}
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  backBtn: { padding: 4 },
  backBtnText: { fontSize: 22, color: Colors.textPrimary },
  avatarSmall: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarSmallText: { fontSize: 16, fontWeight: '700', color: Colors.primary },
  headerInfo: { flex: 1 },
  headerName: { fontSize: 16, fontWeight: '700', color: Colors.textPrimary },
  atVenueRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  greenDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: Colors.success },
  atVenue: { fontSize: 12, color: Colors.success, fontWeight: '600' },
  safetyBtn: {
    backgroundColor: Colors.dangerLight,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  safetyBtnText: { fontSize: 12, fontWeight: '700', color: Colors.danger },
  messageList: { flex: 1 },
  meetupCard: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 3,
  },
  meetupTitle: {
    fontSize: 11,
    fontWeight: '800',
    color: Colors.textMuted,
    letterSpacing: 1,
    marginBottom: 10,
  },
  meetupDropdown: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.background,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 10,
  },
  meetupDropdownText: { fontSize: 15, fontWeight: '600', color: Colors.textPrimary },
  dropdownArrow: { fontSize: 14, color: Colors.textMuted },
  meetupNote: { fontSize: 12, color: Colors.textMuted, fontStyle: 'italic' },
  safetyBanner: {
    backgroundColor: Colors.successLight,
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderLeftWidth: 3,
    borderLeftColor: Colors.success,
  },
  safetyBannerTitle: { fontSize: 13, fontWeight: '700', color: Colors.success },
  safetyBannerSub: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  messageRow: { marginBottom: 12, alignItems: 'flex-start' },
  messageRowMe: { alignItems: 'flex-end' },
  bubble: {
    maxWidth: '78%',
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  bubbleThem: {
    backgroundColor: Colors.white,
    borderTopRightRadius: 18,
    borderTopLeftRadius: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  bubbleMe: {
    backgroundColor: Colors.primary,
    borderTopLeftRadius: 18,
    borderTopRightRadius: 4,
  },
  bubbleText: { fontSize: 15, color: Colors.textPrimary, lineHeight: 20 },
  bubbleTextMe: { color: Colors.white },
  timestamp: { fontSize: 11, color: Colors.textMuted, marginTop: 4, marginHorizontal: 4 },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: 12,
    paddingTop: 10,
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: Colors.divider,
  },
  locationPinBtn: { padding: 6 },
  locationPin: { fontSize: 20 },
  textInput: {
    flex: 1,
    backgroundColor: Colors.background,
    borderRadius: 22,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
    color: Colors.textPrimary,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendBtnText: { fontSize: 18, fontWeight: '700', color: Colors.white },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dropdownMenu: {
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: 16,
    width: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
    elevation: 10,
  },
  dropdownMenuTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: 12,
    letterSpacing: 0.5,
  },
  dropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 10,
  },
  dropdownItemActive: { backgroundColor: Colors.primaryLight },
  dropdownItemText: { fontSize: 15, color: Colors.textPrimary, fontWeight: '500' },
  dropdownItemTextActive: { color: Colors.primary, fontWeight: '700' },
  checkmark: { fontSize: 14, color: Colors.primary, fontWeight: '700' },
});
