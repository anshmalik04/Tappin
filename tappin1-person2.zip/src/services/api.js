/**
 * api.js — Tappin Backend API Service
 *
 * Usage:
 *   import { getHeatmapData, createCheckIn } from '../services/api';
 *
 *   const heatmap = await getHeatmapData();
 *   await createCheckIn('venue-123');
 *
 * Every function automatically attaches the JWT token from Cognito.
 * All errors are caught and thrown with a consistent message.
 */

import { getCurrentToken } from './auth';
import { config } from '../config';

const BASE_URL = config.apiBaseUrl;

// --- Core fetch wrapper ---
async function apiFetch(path, options = {}) {
  const token = await getCurrentToken();

  const response = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || `API error: ${response.status}`);
  }

  return response.json();
}

// --- Heatmap ---
export const getHeatmapData = () =>
  apiFetch('/heatmap');

// --- Venues ---
export const getVenueCard = (venueId) =>
  apiFetch(`/venues/${venueId}`);

export const getPeopleAtVenue = (venueId) =>
  apiFetch(`/venues/${venueId}/people`);

// --- Check-Ins ---
export const createCheckIn = (venueId) =>
  apiFetch('/check-in', {
    method: 'POST',
    body: JSON.stringify({ venueId }),
  });

export const cancelCheckIn = (checkInId) =>
  apiFetch(`/check-in/${checkInId}`, {
    method: 'DELETE',
  });

// --- Tap In ---
export const createTapIn = (receiverId, venueId) =>
  apiFetch('/tap-in', {
    method: 'POST',
    body: JSON.stringify({ receiverId, venueId }),
  });

// --- Matches ---
export const getMatches = () =>
  apiFetch('/matches');

// --- Messages ---
export const getMessages = (matchId) =>
  apiFetch(`/messages/${matchId}`);

export const sendMessage = (matchId, content, meetupSpot = null) =>
  apiFetch('/messages', {
    method: 'POST',
    body: JSON.stringify({ matchId, content, meetupSpot }),
  });

// --- Profile ---
export const getProfile = () =>
  apiFetch('/profile');

export const updateProfile = (data) =>
  apiFetch('/profile', {
    method: 'PUT',
    body: JSON.stringify(data),
  });

// --- Emergency Contacts ---
export const createEmergencyContact = (name, phone) =>
  apiFetch('/emergency-contacts', {
    method: 'POST',
    body: JSON.stringify({ name, phone }),
  });

export const getEmergencyContacts = () =>
  apiFetch('/emergency-contacts');

// --- Photo Upload ---
export const uploadPhoto = (orderIndex, isPrimary, contentType) =>
  apiFetch('/photos/upload', {
    method: 'POST',
    body: JSON.stringify({ orderIndex, isPrimary, contentType }),
  });
