/**
 * websocket.js — Tappin WebSocket Service
 *
 * Usage:
 *   import { connectWebSocket, onHeatmapUpdate, disconnectWebSocket } from '../services/websocket';
 *
 *   connectWebSocket(token);
 *   onHeatmapUpdate((data) => { console.log('Heatmap updated:', data); });
 *   disconnectWebSocket();
 */

import { config } from '../config';

let socket = null;
let heatmapCallback = null;

// --- Connect ---
export const connectWebSocket = (token) => {
  if (socket) return; // already connected

  socket = new WebSocket(`${config.wsUrl}?token=${token}`);

  socket.onopen = () => {
    console.log('[WS] Connected');
    socket.send(JSON.stringify({ action: 'updateHeatmap' }));
  };

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === 'heatmapUpdate' && heatmapCallback) {
        heatmapCallback(data.payload);
      }
    } catch (e) {
      console.warn('[WS] Failed to parse message:', e);
    }
  };

  socket.onerror = (error) => {
    console.error('[WS] Error:', error);
  };

  socket.onclose = () => {
    console.log('[WS] Disconnected');
    socket = null;
  };
};

// --- Subscribe to heatmap updates ---
export const onHeatmapUpdate = (callback) => {
  heatmapCallback = callback;
};

// --- Send a manual heatmap refresh request ---
export const requestHeatmapRefresh = () => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ action: 'updateHeatmap' }));
  }
};

// --- Disconnect ---
export const disconnectWebSocket = () => {
  if (socket) {
    socket.close();
    socket = null;
  }
};
