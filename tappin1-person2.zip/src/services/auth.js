import { Amplify } from 'aws-amplify';
import {
  signUp as amplifySignUp,
  signIn as amplifySignIn,
  confirmSignIn,
  signOut as amplifySignOut,
  getCurrentUser as amplifyGetCurrentUser,
  fetchAuthSession,
} from '@aws-amplify/auth';
import { config } from '../config';

Amplify.configure({
  Auth: {
    Cognito: {
      userPoolId: config.userPoolId,
      userPoolClientId: config.userPoolClientId,
    },
  },
});

export const signUp = async (phone, name, birthdate) => {
  const tempPassword = 'Tappin#' + Math.random().toString(36).slice(-8) + '1!';
  const result = await amplifySignUp({
    username: phone,
    password: tempPassword,
    options: {
      userAttributes: {
        phone_number: phone,
        name: name,
        birthdate: birthdate,
      },
      autoSignIn: false,
    },
  });
  return result;
};

export const signIn = async (phone) => {
  const result = await amplifySignIn({
    username: phone,
    options: {
      authFlowType: 'CUSTOM_WITHOUT_SRP',
    },
  });
  return result;
};

export const confirmOTP = async (phone, code, session) => {
  const result = await confirmSignIn({
    challengeResponse: code,
  });
  return result;
};

export const signOut = async () => {
  await amplifySignOut();
};

export const getCurrentToken = async () => {
  const session = await fetchAuthSession();
  return session.tokens?.idToken?.toString();
};

export const getCurrentUser = async () => {
  const user = await amplifyGetCurrentUser();
  return user;
};
