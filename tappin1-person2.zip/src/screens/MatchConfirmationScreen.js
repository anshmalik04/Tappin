import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  Animated, Dimensions, Image
} from 'react-native';

const { width } = Dimensions.get('window');

const MOCK_MATCH = {
  them: {
    name: "Sarah M.",
    photo: "https://picsum.photos/200/200?random=1"
  },
  me: {
    photo: "https://picsum.photos/200/200?random=2"
  },
  venue: "McGillin's Olde Ale House"
};

export default function MatchConfirmationScreen({ navigation }) {
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.delay(200),
      Animated.parallel([
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 4,
          tension: 40,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true,
        }),
      ]),
    ]).start();
  }, []);

  return (
    <View style={styles.container}>

      {/* Background glow */}
      <View style={styles.glow} />

      {/* Photos */}
      <Animated.View style={[styles.photosRow, {
        opacity: fadeAnim,
        transform: [{ scale: scaleAnim }]
      }]}>
        <Image source={{ uri: MOCK_MATCH.me.photo }} style={styles.photo} />
        <View style={styles.heartContainer}>
          <Text style={styles.heart}>❤️</Text>
        </View>
        <Image source={{ uri: MOCK_MATCH.them.photo }} style={styles.photo} />
      </Animated.View>

      {/* Text */}
      <Animated.View style={{ opacity: fadeAnim }}>
        <Text style={styles.heading}>You both Tapped In!</Text>
        <Text style={styles.subheading}>
          You and {MOCK_MATCH.them.name} matched at
        </Text>
        <Text style={styles.venue}>{MOCK_MATCH.venue}</Text>
      </Animated.View>

      {/* Buttons */}
      <View style={styles.buttons}>
        <TouchableOpacity
          style={styles.chatBtn}
          onPress={() => navigation.navigate('Chat')}
        >
          <Text style={styles.chatBtnText}>Start chatting →</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.browseBtn}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.browseBtnText}>Keep browsing</Text>
        </TouchableOpacity>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a1a',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  glow: {
    position: 'absolute',
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: '#2563eb',
    opacity: 0.15,
    top: '25%',
  },
  photosRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 40,
  },
  photo: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    borderColor: '#2563eb',
  },
  heartContainer: {
    marginHorizontal: 16,
  },
  heart: {
    fontSize: 40,
  },
  heading: {
    fontSize: 32,
    fontWeight: '800',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 12,
  },
  subheading: {
    fontSize: 16,
    color: '#94a3b8',
    textAlign: 'center',
  },
  venue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2563eb',
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 50,
  },
  buttons: {
    width: '100%',
    gap: 12,
  },
  chatBtn: {
    backgroundColor: '#2563eb',
    borderRadius: 14,
    paddingVertical: 18,
    alignItems: 'center',
  },
  chatBtnText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 17,
  },
  browseBtn: {
    backgroundColor: 'transparent',
    borderRadius: 14,
    paddingVertical: 18,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  browseBtnText: {
    color: '#94a3b8',
    fontWeight: '600',
    fontSize: 16,
  },
});