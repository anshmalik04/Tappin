import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const { width } = Dimensions.get('window');

const SLIDES = [
  {
    id: '1',
    emoji: '🗺️',
    title: 'See where everyone\nis going tonight',
    subtitle: 'A live heatmap shows you which venues are packed right now.',
  },
  {
    id: '2',
    emoji: '📍',
    title: 'Check in to up\nto 3 venues',
    subtitle: 'Let people know where you are and contribute to the map.',
  },
  {
    id: '3',
    emoji: '👥',
    title: 'Connect with people\nheading the same way',
    subtitle: 'Tap In with people at the same venue and start a conversation.',
  },
];

export default function OnboardingScreen({ navigation }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef(null);

  function handleScroll(e) {
    const index = Math.round(e.nativeEvent.contentOffset.x / width);
    setCurrentIndex(index);
  }

  function handleNext() {
    if (currentIndex < SLIDES.length - 1) {
      flatListRef.current.scrollToIndex({ index: currentIndex + 1 });
    } else {
      navigation.replace('Phone');
    }
  }

  function handleSkip() {
    navigation.replace('Phone');
  }

  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity style={styles.skipBtn} onPress={handleSkip}>
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      <FlatList
        ref={flatListRef}
        data={SLIDES}
        keyExtractor={item => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        renderItem={({ item }) => (
          <View style={styles.slide}>
            <Text style={styles.emoji}>{item.emoji}</Text>
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.subtitle}>{item.subtitle}</Text>
          </View>
        )}
      />

      <View style={styles.bottom}>
        <View style={styles.dotRow}>
          {SLIDES.map((_, i) => (
            <View key={i} style={[styles.dot, i === currentIndex && styles.dotActive]} />
          ))}
        </View>

        <TouchableOpacity style={styles.nextBtn} onPress={handleNext}>
          <Text style={styles.nextText}>
            {currentIndex === SLIDES.length - 1 ? 'Get Started' : 'Next'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  skipBtn: { alignSelf: 'flex-end', paddingHorizontal: 24, paddingTop: 16 },
  skipText: { fontSize: 15, color: '#8E8E93' },
  slide: { width, flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 40 },
  emoji: { fontSize: 72, marginBottom: 32 },
  title: { fontSize: 28, fontWeight: '800', color: '#1a1a1a', textAlign: 'center', lineHeight: 36, marginBottom: 16 },
  subtitle: { fontSize: 16, color: '#8E8E93', textAlign: 'center', lineHeight: 24 },
  bottom: { paddingHorizontal: 24, paddingBottom: 48, alignItems: 'center', gap: 24 },
  dotRow: { flexDirection: 'row', gap: 8 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#E5E5E5' },
  dotActive: { width: 24, backgroundColor: '#2D7CF6' },
  nextBtn: { backgroundColor: '#2D7CF6', width: width - 48, height: 54, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  nextText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
