import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getCurrentToken } from '../services/auth';

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    const bootstrap = async () => {
      try {
        const token = await getCurrentToken();
        if (token) {
          // Already logged in — go straight to main app
          navigation.replace('Main');
        } else {
          // Not logged in — show onboarding
          navigation.replace('Onboarding');
        }
      } catch (err) {
        // Any error means not logged in
        navigation.replace('Onboarding');
      }
    };

    const timer = setTimeout(bootstrap, 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.logoContainer}>
        <View style={styles.logoBox}>
          <Text style={styles.logoLetter}>T</Text>
        </View>
        <Text style={styles.appName}>Tappin</Text>
        <Text style={styles.tagline}>Tap Into the Scene</Text>
      </View>
      <View style={styles.bottom}>
        <ActivityIndicator color="#2D7CF6" size="small" />
        <Text style={styles.findingText}>Finding your location...</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', justifyContent: 'space-between' },
  logoContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  logoBox: { width: 90, height: 90, backgroundColor: '#2D7CF6', borderRadius: 22, justifyContent: 'center', alignItems: 'center', marginBottom: 16, shadowColor: '#2D7CF6', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.3, shadowRadius: 16 },
  logoLetter: { fontSize: 52, fontWeight: '800', color: '#fff' },
  appName: { fontSize: 36, fontWeight: '800', color: '#1a1a1a', letterSpacing: -1 },
  tagline: { fontSize: 16, color: '#8E8E93', marginTop: 8, letterSpacing: 0.3 },
  bottom: { alignItems: 'center', paddingBottom: 48, gap: 10 },
  findingText: { fontSize: 14, color: '#8E8E93' },
});
