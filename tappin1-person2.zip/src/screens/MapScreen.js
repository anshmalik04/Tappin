import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  ScrollView, Dimensions, ActivityIndicator,
} from 'react-native';
import MapView, { Circle, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import * as Location from 'expo-location';

const { width, height } = Dimensions.get('window');

// ─── MOCK VENUES (replace with getHeatmapData() when API is ready) ───────────

const FILTERS = ['All', 'Bars', 'Clubs', 'Events', 'Food'];

function getHeatColor(score) {
  if (score > 70) return { fill: 'rgba(255,59,48,0.25)', stroke: '#FF3B30' };
  if (score > 40) return { fill: 'rgba(255,149,0,0.25)', stroke: '#FF9500' };
  if (score > 15) return { fill: 'rgba(142,142,147,0.2)', stroke: '#8E8E93' };
  return { fill: 'rgba(199,199,204,0.15)', stroke: '#C7C7CC' };
}

function getHeatRadius(score) {
  if (score > 70) return 120;
  if (score > 40) return 90;
  if (score > 15) return 70;
  return 50;
}

export default function MapScreen({ navigation }) {
  const [location, setLocation] = useState(null);
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [selectedVenue, setSelectedVenue] = useState(null);
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const mapRef = useRef(null);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({});
        setLocation(loc.coords);
      }
      try {
        const data = await getHeatmapData();
        setVenues(data.venues || []);
      } catch (err) {
        console.warn('Heatmap fetch failed:', err.message);
        setVenues([]);
      }
      setLoading(false);
    })();
  }, []);

  const filteredVenues = venues.filter(v => {
    const matchesFilter =
      filter === 'All' ||
      (filter === 'Bars' && v.type === 'Bar') ||
      (filter === 'Clubs' && v.type === 'Club');
    const matchesSearch = v.name.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const initialRegion = {
    latitude: location?.latitude ?? 39.9526,
    longitude: location?.longitude ?? -75.1652,
    latitudeDelta: 0.02,
    longitudeDelta: 0.02,
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2D7CF6" />
        <Text style={styles.loadingText}>Finding your location...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* ── Search bar ── */}
      <View style={styles.searchBar}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Search venues..."
          placeholderTextColor="#aaa"
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Text style={styles.clearSearch}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* ── Filter chips ── */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterRow}
        contentContainerStyle={styles.filterContent}
      >
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, filter === f && styles.filterChipActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* ── Map ── */}
      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={initialRegion}
        showsUserLocation
        showsMyLocationButton={false}
        onPress={() => setSelectedVenue(null)}
      >
        {filteredVenues.map(venue => {
          const colors = getHeatColor(venue.score);
          const radius = getHeatRadius(venue.score);
          return (
            <React.Fragment key={venue.id}>
              <Circle
                center={{ latitude: venue.lat, longitude: venue.lng }}
                radius={radius}
                fillColor={colors.fill}
                strokeColor={colors.stroke}
                strokeWidth={2}
              />
              <Marker
                coordinate={{ latitude: venue.lat, longitude: venue.lng }}
                onPress={() => setSelectedVenue(venue)}
              >
                <View style={[styles.markerDot, { backgroundColor: colors.stroke }]}>
                  <Text style={styles.markerCount}>{venue.arrived}</Text>
                </View>
              </Marker>
            </React.Fragment>
          );
        })}
      </MapView>

      {/* ── Venue preview card ── */}
      {selectedVenue && (
        <TouchableOpacity
          style={styles.previewCard}
          onPress={() => navigation.navigate('VenueCard', { venueId: selectedVenue.id })}
          activeOpacity={0.9}
        >
          <View style={styles.previewCardInner}>
            <View style={styles.previewLeft}>
              <Text style={styles.previewName}>{selectedVenue.name}</Text>
              <Text style={styles.previewMeta}>
                {selectedVenue.arrived} here now · {selectedVenue.going} going
              </Text>
            </View>
            <View style={[styles.heatDot, { backgroundColor: getHeatColor(selectedVenue.score).stroke }]} />
            <Text style={styles.previewArrow}>›</Text>
          </View>
        </TouchableOpacity>
      )}

      {/* ── My location button ── */}
      <TouchableOpacity
        style={styles.locationBtn}
        onPress={() => {
          if (location && mapRef.current) {
            mapRef.current.animateToRegion({
              latitude: location.latitude,
              longitude: location.longitude,
              latitudeDelta: 0.02,
              longitudeDelta: 0.02,
            }, 500);
          }
        }}
      >
        <Text style={styles.locationBtnText}>📍</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  loadingText: { marginTop: 12, color: '#8E8E93', fontSize: 15 },

  searchBar: {
    position: 'absolute', top: 56, left: 16, right: 16, zIndex: 10,
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#fff', borderRadius: 14,
    paddingHorizontal: 12, paddingVertical: 10,
    shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 8, shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  searchIcon: { fontSize: 16, marginRight: 8 },
  searchInput: { flex: 1, fontSize: 15, color: '#1a1a1a' },
  clearSearch: { fontSize: 14, color: '#aaa', paddingLeft: 8 },

  filterRow: { position: 'absolute', top: 116, left: 0, right: 0, zIndex: 10 },
  filterContent: { paddingHorizontal: 16, gap: 8 },
  filterChip: {
    backgroundColor: '#fff', borderRadius: 20, paddingHorizontal: 16, paddingVertical: 7,
    borderWidth: 1.5, borderColor: '#ddd',
    shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { width: 0, height: 1 },
  },
  filterChipActive: { backgroundColor: '#2D7CF6', borderColor: '#2D7CF6' },
  filterText: { fontSize: 13, fontWeight: '600', color: '#555' },
  filterTextActive: { color: '#fff' },

  map: { flex: 1 },

  markerDot: {
    width: 36, height: 36, borderRadius: 18,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: '#fff',
    shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 4,
  },
  markerCount: { color: '#fff', fontSize: 12, fontWeight: '700' },

  previewCard: {
    position: 'absolute', bottom: 24, left: 16, right: 16,
    backgroundColor: '#fff', borderRadius: 16,
    shadowColor: '#000', shadowOpacity: 0.15, shadowRadius: 12, shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  previewCardInner: { flexDirection: 'row', alignItems: 'center', padding: 16 },
  previewLeft: { flex: 1 },
  previewName: { fontSize: 16, fontWeight: '700', color: '#1a1a1a', marginBottom: 4 },
  previewMeta: { fontSize: 13, color: '#8E8E93' },
  heatDot: { width: 12, height: 12, borderRadius: 6, marginRight: 10 },
  previewArrow: { fontSize: 22, color: '#2D7CF6', fontWeight: '600' },

  locationBtn: {
    position: 'absolute', bottom: 100, right: 16,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center',
    shadowColor: '#000', shadowOpacity: 0.15, shadowRadius: 8, shadowOffset: { width: 0, height: 2 },
  },
  locationBtnText: { fontSize: 20 },
});
