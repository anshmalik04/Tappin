import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Image, Modal, TextInput
} from 'react-native';

const MOCK_USER = {
  name: 'Mithil S.',
  age: 24,
  bio: 'Always down for a good night out 🎶',
  is_verified: true,
  is_pro: false,
  personality_tags: ['Social', 'Adventurous', 'Night owl'],
  music_taste: ['House', 'R&B', 'Indie'],
  photos: [
    'https://picsum.photos/400/400?random=10',
    'https://picsum.photos/400/400?random=11',
    'https://picsum.photos/400/400?random=12',
  ],
};

export default function MyProfileScreen({ navigation }) {
  const [user, setUser] = useState(MOCK_USER);
  const [showBioModal, setShowBioModal] = useState(false);
  const [showTagModal, setShowTagModal] = useState(false);
  const [showMusicModal, setShowMusicModal] = useState(false);
  const [editBio, setEditBio] = useState(user.bio);

  const ALL_TAGS = ['Social', 'Adventurous', 'Night owl', 'Chill', 'Foodie', 'Sporty', 'Creative', 'Traveler'];
  const ALL_MUSIC = ['House', 'R&B', 'Indie', 'Hip-hop', 'Pop', 'Jazz', 'Rock', 'EDM'];

  const saveBio = () => {
    setUser(prev => ({ ...prev, bio: editBio }));
    setShowBioModal(false);
  };

  const toggleTag = (tag, field) => {
    setUser(prev => {
      const current = prev[field];
      const updated = current.includes(tag)
        ? current.filter(t => t !== tag)
        : [...current, tag];
      return { ...prev, [field]: updated };
    });
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>

        <View style={styles.header}>
          <Text style={styles.headerTitle}>My Profile</Text>
        </View>

        <View style={styles.photoSection}>
          <View style={styles.primaryPhotoContainer}>
            <Image source={{ uri: user.photos[0] }} style={styles.primaryPhoto} />
            <TouchableOpacity style={styles.cameraOverlay}>
              <Text style={styles.cameraIcon}>📷</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.userName}>{user.name}, {user.age}</Text>
          <View style={styles.badgeRow}>
            {user.is_verified && (
              <View style={styles.verifiedBadge}>
                <Text style={styles.verifiedText}>✓ VERIFIED</Text>
              </View>
            )}
            {user.is_pro && (
              <View style={styles.proBadge}>
                <Text style={styles.proText}>PRO</Text>
              </View>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Bio</Text>
            <TouchableOpacity onPress={() => { setEditBio(user.bio); setShowBioModal(true); }}>
              <Text style={styles.editBtn}>Edit</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.bioText}>{user.bio}</Text>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Vibe</Text>
            <TouchableOpacity onPress={() => setShowTagModal(true)}>
              <Text style={styles.editBtn}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.chips}>
            {user.personality_tags.map(tag => (
              <View key={tag} style={styles.chip}>
                <Text style={styles.chipText}>{tag}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Music</Text>
            <TouchableOpacity onPress={() => setShowMusicModal(true)}>
              <Text style={styles.editBtn}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.chips}>
            {user.music_taste.map(genre => (
              <View key={genre} style={styles.chip}>
                <Text style={styles.chipText}>{genre}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Photos</Text>
          <View style={styles.photoGrid}>
            {user.photos.map((photo, index) => (
              <TouchableOpacity key={index} style={styles.gridPhoto}>
                <Image source={{ uri: photo }} style={styles.gridPhotoImg} />
              </TouchableOpacity>
            ))}
            {user.photos.length < 6 && (
              <TouchableOpacity style={styles.addPhotoBtn}>
                <Text style={styles.addPhotoBtnText}>+</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <TouchableOpacity
            style={styles.settingsRow}
            onPress={() => navigation.navigate('EmergencyContacts')}
          >
            <Text style={styles.settingsRowText}>🛡 Emergency contacts</Text>
            <Text style={styles.settingsArrow}>›</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingsRow}>
            <Text style={styles.settingsRowText}>🔒 Privacy settings</Text>
            <Text style={styles.settingsArrow}>›</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingsRow}>
            <Text style={styles.settingsRowText}>⭐ Upgrade to Pro</Text>
            <Text style={styles.settingsArrow}>›</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.signOutBtn}>
          <Text style={styles.signOutText}>Sign out</Text>
        </TouchableOpacity>

      </ScrollView>

      <Modal visible={showBioModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Edit bio</Text>
            <TextInput
              style={styles.bioInput}
              value={editBio}
              onChangeText={setEditBio}
              multiline
              maxLength={150}
              placeholder="Tell people about yourself..."
              placeholderTextColor="#aaa"
            />
            <Text style={styles.charCount}>{editBio.length}/150</Text>
            <TouchableOpacity style={styles.saveBtn} onPress={saveBio}>
              <Text style={styles.saveBtnText}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowBioModal(false)}>
              <Text style={styles.cancelBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showTagModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Edit vibe tags</Text>
            <View style={styles.chips}>
              {ALL_TAGS.map(tag => (
                <TouchableOpacity
                  key={tag}
                  style={[styles.chip, user.personality_tags.includes(tag) && styles.chipSelected]}
                  onPress={() => toggleTag(tag, 'personality_tags')}
                >
                  <Text style={[styles.chipText, user.personality_tags.includes(tag) && styles.chipTextSelected]}>
                    {tag}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={styles.saveBtn} onPress={() => setShowTagModal(false)}>
              <Text style={styles.saveBtnText}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showMusicModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Edit music taste</Text>
            <View style={styles.chips}>
              {ALL_MUSIC.map(genre => (
                <TouchableOpacity
                  key={genre}
                  style={[styles.chip, user.music_taste.includes(genre) && styles.chipSelected]}
                  onPress={() => toggleTag(genre, 'music_taste')}
                >
                  <Text style={[styles.chipText, user.music_taste.includes(genre) && styles.chipTextSelected]}>
                    {genre}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={styles.saveBtn} onPress={() => setShowMusicModal(false)}>
              <Text style={styles.saveBtnText}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  scroll: { paddingBottom: 60 },
  header: {
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: { fontSize: 28, fontWeight: '800', color: '#111' },
  photoSection: { alignItems: 'center', paddingVertical: 24 },
  primaryPhotoContainer: { position: 'relative', marginBottom: 12 },
  primaryPhoto: { width: 100, height: 100, borderRadius: 50 },
  cameraOverlay: {
    position: 'absolute', bottom: 0, right: 0,
    backgroundColor: '#2563eb', borderRadius: 14,
    width: 28, height: 28, alignItems: 'center', justifyContent: 'center',
  },
  cameraIcon: { fontSize: 14 },
  userName: { fontSize: 22, fontWeight: '700', color: '#111', marginBottom: 6 },
  badgeRow: { flexDirection: 'row', gap: 8 },
  verifiedBadge: {
    backgroundColor: '#22c55e', borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  verifiedText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  proBadge: {
    backgroundColor: '#2563eb', borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  proText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  section: {
    paddingHorizontal: 20, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: '#f0f0f0',
  },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#111' },
  editBtn: { fontSize: 14, color: '#2563eb', fontWeight: '600' },
  bioText: { fontSize: 15, color: '#444', lineHeight: 22 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    backgroundColor: '#eff6ff', borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 6,
  },
  chipSelected: { backgroundColor: '#2563eb' },
  chipText: { color: '#2563eb', fontSize: 13, fontWeight: '500' },
  chipTextSelected: { color: '#fff' },
  photoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  gridPhoto: { width: 100, height: 100, borderRadius: 10, overflow: 'hidden' },
  gridPhotoImg: { width: '100%', height: '100%' },
  addPhotoBtn: {
    width: 100, height: 100, borderRadius: 10,
    borderWidth: 2, borderColor: '#2563eb', borderStyle: 'dashed',
    alignItems: 'center', justifyContent: 'center',
  },
  addPhotoBtnText: { fontSize: 32, color: '#2563eb' },
  settingsRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: '#f0f0f0',
  },
  settingsRowText: { fontSize: 15, color: '#111' },
  settingsArrow: { fontSize: 18, color: '#aaa' },
  signOutBtn: { margin: 20, paddingVertical: 16, alignItems: 'center' },
  signOutText: { color: '#ef4444', fontSize: 16, fontWeight: '600' },
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end',
  },
  modalSheet: {
    backgroundColor: '#fff', borderTopLeftRadius: 20,
    borderTopRightRadius: 20, padding: 24, paddingBottom: 40,
  },
  modalTitle: {
    fontSize: 18, fontWeight: '700', color: '#111',
    marginBottom: 16, textAlign: 'center',
  },
  bioInput: {
    backgroundColor: '#f1f5f9', borderRadius: 10,
    padding: 14, fontSize: 15, color: '#111',
    minHeight: 100, textAlignVertical: 'top', marginBottom: 8,
  },
  charCount: { fontSize: 12, color: '#aaa', textAlign: 'right', marginBottom: 16 },
  saveBtn: {
    backgroundColor: '#2563eb', borderRadius: 12,
    paddingVertical: 16, alignItems: 'center',
  },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  cancelBtn: { paddingVertical: 14, alignItems: 'center' },
  cancelBtnText: { color: '#888', fontSize: 15, fontWeight: '600' },
});