import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ActivityIndicator, KeyboardAvoidingView, Platform, Alert, ScrollView,
} from 'react-native';
import { signIn, signUp } from '../../services/auth';

export default function PhoneScreen({ navigation }) {
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [birthdate, setBirthdate] = useState('');
  const [loading, setLoading] = useState(false);

  const formatPhone = (raw) => `+1${raw.replace(/\D/g, '')}`;

  const formatDateInput = (text) => {
    const digits = text.replace(/\D/g, '');
    if (digits.length <= 2) return digits;
    if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4, 8)}`;
  };

  const isOver18 = (dobString) => {
    const [month, day, year] = dobString.split('/');
    const dob = new Date(`${year}-${month}-${day}`);
    if (isNaN(dob)) return false;
    const today = new Date();
    const age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      return age - 1 >= 18;
    }
    return age >= 18;
  };

  const handleSendCode = async () => {
    const digits = phone.replace(/\D/g, '');
    if (!name.trim()) {
      Alert.alert('Missing name', 'Please enter your first name.');
      return;
    }
    if (birthdate.length !== 10) {
      Alert.alert('Invalid date', 'Please enter your date of birth as MM/DD/YYYY.');
      return;
    }
    if (!isOver18(birthdate)) {
      Alert.alert('Age Requirement', 'You must be 18 or older to use Tappin.');
      return;
    }
    if (digits.length !== 10) {
      Alert.alert('Invalid number', 'Please enter a valid 10-digit US phone number.');
      return;
    }

    const formattedPhone = formatPhone(phone);
    const [month, day, year] = birthdate.split('/');
    const isoDate = `${year}-${month}-${day}`;

    setLoading(true);

    try {
      // Try signUp first
      console.log('Attempting signUp for:', formattedPhone);
      try {
        await signUp(formattedPhone, name.trim(), isoDate);
        console.log('SignUp successful — new user created');
      } catch (signUpErr) {
        console.log('SignUp error:', signUpErr.name, signUpErr.message);
        if (
          !signUpErr.name?.includes('UsernameExists') &&
          !signUpErr.message?.includes('already exists') &&
          !signUpErr.message?.includes('User already exists')
        ) {
          throw signUpErr;
        }
        console.log('User already exists — proceeding to signIn');
      }

      // Now sign in to trigger OTP
      console.log('Attempting signIn for:', formattedPhone);
      const result = await signIn(formattedPhone);
      console.log('SignIn result:', result?.nextStep?.signInStep);
      navigation.navigate('OTP', { phone: formattedPhone, session: result });

    } catch (err) {
      console.log('Final error:', err.name, err.message);
      Alert.alert('Error', err.message || 'Could not send code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.inner}>
        <Text style={styles.logo}>Tappin</Text>
        <Text style={styles.tagline}>Tap Into the Scene</Text>

        <Text style={styles.label}>First name</Text>
        <TextInput
          style={styles.input}
          placeholder="Your first name"
          value={name}
          onChangeText={setName}
          autoCapitalize="words"
        />

        <Text style={styles.label}>Date of birth</Text>
        <TextInput
          style={styles.input}
          placeholder="MM/DD/YYYY"
          value={birthdate}
          onChangeText={(text) => setBirthdate(formatDateInput(text))}
          keyboardType="number-pad"
          maxLength={10}
        />

        <Text style={styles.label}>Phone number</Text>
        <View style={styles.inputRow}>
          <View style={styles.countryCode}>
            <Text style={styles.countryCodeText}>🇺🇸 +1</Text>
          </View>
          <TextInput
            style={styles.input}
            placeholder="(215) 555-0123"
            keyboardType="phone-pad"
            maxLength={14}
            value={phone}
            onChangeText={setPhone}
          />
        </View>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleSendCode}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Send Code</Text>}
        </TouchableOpacity>

        <Text style={styles.disclaimer}>By continuing, you agree to our Terms of Service and Privacy Policy.</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  inner: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 32, paddingVertical: 48 },
  logo: { fontSize: 40, fontWeight: '800', color: '#1a73e8', marginBottom: 4, textAlign: 'center' },
  tagline: { fontSize: 14, color: '#888', marginBottom: 40, textAlign: 'center' },
  label: { fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 8 },
  inputRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  countryCode: { backgroundColor: '#f0f0f0', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 14, marginRight: 8 },
  countryCodeText: { fontSize: 16 },
  input: { flex: 1, backgroundColor: '#f0f0f0', borderRadius: 10, paddingHorizontal: 16, paddingVertical: 14, fontSize: 16, marginBottom: 20 },
  button: { backgroundColor: '#1a73e8', borderRadius: 12, paddingVertical: 16, alignItems: 'center', marginBottom: 24, marginTop: 8 },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  disclaimer: { fontSize: 12, color: '#aaa', textAlign: 'center', lineHeight: 18 },
});
