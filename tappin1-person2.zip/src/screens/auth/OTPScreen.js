import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { confirmOTP, signIn, getCurrentToken } from '../../services/auth';

export default function OTPScreen({ route, navigation }) {
  const { phone, session } = route.params;
  const [digits, setDigits] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const inputs = useRef([]);

  const handleDigitChange = (text, index) => {
    const newDigits = [...digits];
    newDigits[index] = text.slice(-1);
    setDigits(newDigits);
    if (text && index < 5) {
      inputs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === 'Backspace' && !digits[index] && index > 0) {
      inputs.current[index - 1]?.focus();
    }
  };

  const handleVerify = async () => {
    const code = digits.join('');
    if (code.length !== 6) {
      Alert.alert('Incomplete code', 'Please enter all 6 digits.');
      return;
    }

    setLoading(true);
    try {
      console.log('Confirming OTP:', code);
      await confirmOTP(phone, code, session);
      console.log('OTP confirmed successfully');

      // Try to get token, but don't block navigation if it fails
      try {
        const token = await getCurrentToken();
        console.log('Token retrieved:', token ? 'yes' : 'no');
        if (token) {
          await AsyncStorage.setItem('tappin_jwt', token);
        }
      } catch (tokenErr) {
        console.log('Token fetch error (non-blocking):', tokenErr.message);
      }

      // Navigate regardless — token will be fetched fresh when needed
      navigation.replace('ProfileSetup', { phone });

    } catch (err) {
      console.log('OTP error:', err.name, err.message);
      Alert.alert('Invalid code', err.message || 'The code was incorrect. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    try {
      await signIn(phone);
      Alert.alert('Code sent', 'A new code has been sent. Check CloudWatch logs for the OTP.');
    } catch (err) {
      Alert.alert('Error', 'Could not resend code. Please go back and try again.');
    }
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.inner}>
        <Text style={styles.title}>Enter the code</Text>
        <Text style={styles.subtitle}>Sent to {phone}</Text>

        <View style={styles.digitRow}>
          {digits.map((digit, index) => (
            <TextInput
              key={index}
              ref={(ref) => (inputs.current[index] = ref)}
              style={[styles.digitBox, digit ? styles.digitBoxFilled : null]}
              value={digit}
              onChangeText={(text) => handleDigitChange(text, index)}
              onKeyPress={(e) => handleKeyPress(e, index)}
              keyboardType="number-pad"
              maxLength={1}
              autoFocus={index === 0}
              selectTextOnFocus
            />
          ))}
        </View>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleVerify}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Verify</Text>}
        </TouchableOpacity>

        <TouchableOpacity onPress={handleResend} style={styles.resendLink}>
          <Text style={styles.resendText}>Didn't get it? Resend code</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  inner: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 32 },
  title: { fontSize: 28, fontWeight: '800', color: '#1a73e8', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#888', marginBottom: 40 },
  digitRow: { flexDirection: 'row', gap: 10, marginBottom: 32 },
  digitBox: {
    width: 48, height: 56, borderRadius: 10, backgroundColor: '#f0f0f0',
    fontSize: 24, fontWeight: '700', textAlign: 'center', color: '#333',
  },
  digitBoxFilled: { backgroundColor: '#e8f0fe', borderWidth: 2, borderColor: '#1a73e8' },
  button: {
    backgroundColor: '#1a73e8', borderRadius: 12, paddingVertical: 16,
    width: '100%', alignItems: 'center', marginBottom: 16,
  },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  resendLink: { paddingVertical: 8 },
  resendText: { color: '#1a73e8', fontSize: 14, fontWeight: '600' },
});
