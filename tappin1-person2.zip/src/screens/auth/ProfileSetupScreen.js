import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';

export default function ProfileSetupScreen({ navigation }) {
  const [name, setName] = useState('');
  const [birthdate, setBirthdate] = useState('');
  const [loading, setLoading] = useState(false);

  const isOver18 = (dobString) => {
    const [month, day, year] = dobString.split('/');
    const dob = new Date(`${year}-${month}-${day}`);
    if (isNaN(dob)) return false;
    const today = new Date();
    const age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      return age - 1 >= 18;
    }
    return age >= 18;
  };

  const formatDateInput = (text) => {
    const digits = text.replace(/\D/g, '');
    if (digits.length <= 2) return digits;
    if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4, 8)}`;
  };

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('Missing name', 'Please enter your first name.');
      return;
    }
    if (birthdate.length !== 10) {
      Alert.alert('Invalid date', 'Please enter your date of birth as MM/DD/YYYY.');
      return;
    }
    if (!isOver18(birthdate)) {
      Alert.alert('Age Requirement', "You must be 18 or older to use Tappin.");
      return;
    }

    setLoading(true);
    // TODO: call api.updateProfile() once JWT token flow is working with Twilio
    console.log('Profile setup complete:', { name, birthdate });
    setTimeout(() => {
      navigation.replace('MainApp');
    }, 500);
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.inner}>
        <Text style={styles.title}>Set up your profile</Text>
        <Text style={styles.subtitle}>Just the basics to get you started</Text>

        <Text style={styles.label}>First name</Text>
        <TextInput
          style={styles.input}
          placeholder="Your first name"
          value={name}
          onChangeText={setName}
          autoCapitalize="words"
          autoFocus
        />

        <Text style={styles.label}>Date of birth</Text>
        <TextInput
          style={styles.input}
          placeholder="MM/DD/YYYY"
          value={birthdate}
          onChangeText={(text) => setBirthdate(formatDateInput(text))}
          keyboardType="number-pad"
          maxLength={10}
        />
        <Text style={styles.hint}>You must be 18 or older to use Tappin.</Text>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleSave}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Let's go →</Text>}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  inner: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 32, paddingVertical: 48 },
  title: { fontSize: 28, fontWeight: '800', color: '#1a73e8', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#888', marginBottom: 40 },
  label: { fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 8 },
  input: {
    backgroundColor: '#f0f0f0', borderRadius: 10, paddingHorizontal: 16,
    paddingVertical: 14, fontSize: 16, marginBottom: 8,
  },
  hint: { fontSize: 12, color: '#aaa', marginBottom: 32 },
  button: {
    backgroundColor: '#1a73e8', borderRadius: 12, paddingVertical: 16, alignItems: 'center',
  },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
