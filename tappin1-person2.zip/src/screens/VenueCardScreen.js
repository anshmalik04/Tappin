import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  FlatList, Image, ActivityIndicator, Alert, Dimensions, Vibration
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

// Swap these in once api.js is confirmed available:
import { getVenueDetails, createCheckIn, cancelCheckIn, getActiveCheckIns } from '../services/api';

const { width } = Dimensions.get('window');



export default function VenueCardScreen({ route, navigation }) {
  const venueId = route?.params?.venueId ?? 'venue_001';

  const [venue, setVenue] = useState(null);
  const [loading, setLoading] = useState(true);
  const [photoIndex, setPhotoIndex] = useState(0);
  const [checkedIn, setCheckedIn] = useState(false);
  const [activeCheckInId, setActiveCheckInId] = useState(null);
  const [activeCheckInCount, setActiveCheckInCount] = useState(0);
  const [checkInLoading, setCheckInLoading] = useState(false);

  const flatListRef = useRef(null);

  // ── Load venue + check-in state ────────────────────────────────────────────
  useEffect(() => {
    loadVenueData();
  }, [venueId]);

  async function loadVenueData() {
    setLoading(true);
    try {
      // REAL API (uncomment when api.js is ready):
      // const [venueData, checkIns] = await Promise.all([
      //   getVenueDetails(venueId),
      //   getActiveCheckIns(),
      // ]);
      // setVenue(venueData);
      // const existing = checkIns.find(ci => ci.venue_id === venueId);
      // setCheckedIn(!!existing);
      // setActiveCheckInId(existing?.id ?? null);
      // setActiveCheckInCount(checkIns.length);

      const venueData = await getVenueCard(venueId);
      setVenue(venueData);
      setCheckedIn(venueData.user_checked_in || false);
      setActiveCheckInId(venueData.user_checkin_id || null);
      setActiveCheckInCount(venueData.user_checkin_count || 0);
    } catch (err) {
      Alert.alert('Error', 'Could not load venue. Pull down to retry.');
    } finally {
      setLoading(false);
    }
  }

  // ── Check-in logic ─────────────────────────────────────────────────────────
  async function handleCheckIn() {
    if (activeCheckInCount >= 3 && !checkedIn) {
      Alert.alert(
        'Check-In Limit Reached',
        "You're already checked in to 3 venues. Cancel one to check in here.",
        [{ text: 'OK' }]
      );
      return;
    }

    setCheckInLoading(true);
    Vibration.vibrate(40);

    try {
      if (checkedIn) {
        // Cancel check-in
       await cancelCheckIn(activeCheckInId);
        setCheckedIn(false);
        setActiveCheckInId(null);
        setActiveCheckInCount(prev => prev - 1);
        setVenue(v => ({ ...v, arrived_count: v.arrived_count - 1 }));
      } else {
        // Create check-in
        const result = await createCheckIn(venueId);
        setActiveCheckInId(result.id);
        setCheckedIn(true);
        setActiveCheckInCount(prev => prev + 1);
        setVenue(v => ({ ...v, arrived_count: v.arrived_count + 1 }));
      }
    } catch (err) {
      Alert.alert('Error', 'Check-in failed. Please try again.');
    } finally {
      setCheckInLoading(false);
    }
  }

  // ── Scroll handler for photo carousel ──────────────────────────────────────
  function handlePhotoScroll(e) {
    const index = Math.round(e.nativeEvent.contentOffset.x / width);
    setPhotoIndex(index);
  }

  // ── Heat label ──────────────────────────────────────────────────────────────
  function getHeatLabel(score) {
    if (score > 70) return { label: '🔴 Hot', color: '#FF3B30' };
    if (score > 40) return { label: '🟠 Warm', color: '#FF9500' };
    if (score > 15) return { label: '⚫ Mild', color: '#8E8E93' };
    return { label: '⚪ Quiet', color: '#C7C7CC' };
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2D7CF6" />
        <Text style={styles.loadingText}>Loading venue...</Text>
      </SafeAreaView>
    );
  }

  if (!venue) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <Text style={styles.errorText}>Venue not found.</Text>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>Go Back</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  const heat = getHeatLabel(venue.heatmap_score);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Back arrow */}
      <TouchableOpacity style={styles.backArrow} onPress={() => navigation.goBack()}>
        <Text style={styles.backArrowText}>‹ Back</Text>
      </TouchableOpacity>

      <ScrollView showsVerticalScrollIndicator={false} bounces={true}>

        {/* ── Photo carousel ── */}
        <View>
          <FlatList
            ref={flatListRef}
            data={venue.photos}
            keyExtractor={(_, i) => String(i)}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={handlePhotoScroll}
            scrollEventThrottle={16}
            renderItem={({ item }) => (
              <Image
                source={{ uri: item }}
                style={styles.photo}
                resizeMode="cover"
              />
            )}
          />

          {/* Photo counter badge */}
          <View style={styles.photoCounter}>
            <Text style={styles.photoCounterText}>
              {photoIndex + 1}/{venue.photos.length}
            </Text>
          </View>

          {/* Dot indicators */}
          <View style={styles.dotRow}>
            {venue.photos.map((_, i) => (
              <View
                key={i}
                style={[styles.dot, i === photoIndex && styles.dotActive]}
              />
            ))}
          </View>
        </View>

        {/* ── Venue details ── */}
        <View style={styles.details}>
          <View style={styles.nameRow}>
            <Text style={styles.venueName}>{venue.name}</Text>
            <Text style={[styles.heatBadge, { color: heat.color }]}>{heat.label}</Text>
          </View>

          <Text style={styles.address}>{venue.address}</Text>

          <View style={styles.metaRow}>
            <Text style={styles.metaItem}>🕐 {venue.hours}</Text>
            <Text style={styles.metaItem}>🎟 Cover: {venue.cover_charge}</Text>
          </View>

          {/* Going / Arrived counts */}
          <View style={styles.countsRow}>
            <View style={styles.countBox}>
              <Text style={styles.countNumber}>{venue.going_count}</Text>
              <Text style={styles.countLabel}>Going Tonight</Text>
            </View>
            <View style={styles.countDivider} />
            <View style={styles.countBox}>
              <Text style={styles.countNumber}>{venue.arrived_count}</Text>
              <Text style={styles.countLabel}>Here Now</Text>
            </View>
          </View>

          {/* Vibe tags */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tagsScroll}>
            {venue.vibe_tags.map(tag => (
              <View key={tag} style={styles.vibeTag}>
                <Text style={styles.vibeTagText}>{tag}</Text>
              </View>
            ))}
          </ScrollView>

          {/* ── Check-in button ── */}
          {checkedIn ? (
            <View>
              <View style={styles.checkedInBadge}>
                <Text style={styles.checkedInBadgeText}>✓ Checked In</Text>
              </View>
              <TouchableOpacity
                style={[styles.button, styles.cancelButton]}
                onPress={handleCheckIn}
                disabled={checkInLoading}
              >
                {checkInLoading
                  ? <ActivityIndicator color="#FF3B30" />
                  : <Text style={styles.cancelButtonText}>Cancel Check-In</Text>
                }
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity
              style={[
                styles.button,
                styles.checkInButton,
                activeCheckInCount >= 3 && styles.buttonDisabled
              ]}
              onPress={handleCheckIn}
              disabled={checkInLoading}
            >
              {checkInLoading
                ? <ActivityIndicator color="#fff" />
                : <Text style={styles.checkInButtonText}>
                    {activeCheckInCount >= 3 ? 'Check-In Limit Reached (3/3)' : 'Check In Here'}
                  </Text>
              }
            </TouchableOpacity>
          )}

          {/* ── See People Here (Person 3 builds that screen) ── */}
          <TouchableOpacity
            style={[styles.button, styles.peopleButton]}
            onPress={() => navigation.navigate('PeopleAtVenue', { venueId: venue.id, venueName: venue.name })}
          >
            <Text style={styles.peopleButtonText}>👥 See People Here</Text>
          </TouchableOpacity>

        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── STYLES ──────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  loadingText: { marginTop: 12, color: '#8E8E93', fontSize: 15 },
  errorText: { color: '#8E8E93', fontSize: 16, marginBottom: 16 },

  backArrow: { position: 'absolute', top: 56, left: 16, zIndex: 10, backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6 },
  backArrowText: { fontSize: 18, color: '#2D7CF6', fontWeight: '600' },
  backBtn: { backgroundColor: '#2D7CF6', borderRadius: 12, paddingHorizontal: 24, paddingVertical: 10 },
  backBtnText: { color: '#fff', fontWeight: '600' },

  photo: { width, height: 240 },
  photoCounter: { position: 'absolute', top: 12, right: 12, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 12, paddingHorizontal: 8, paddingVertical: 4 },
  photoCounterText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  dotRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 8, gap: 6 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#C7C7CC' },
  dotActive: { backgroundColor: '#2D7CF6', width: 18 },

  details: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 40 },
  nameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 },
  venueName: { fontSize: 22, fontWeight: '700', color: '#1a1a1a', flex: 1, marginRight: 8 },
  heatBadge: { fontSize: 13, fontWeight: '700' },
  address: { color: '#8E8E93', fontSize: 14, marginBottom: 10 },

  metaRow: { flexDirection: 'row', gap: 16, marginBottom: 16 },
  metaItem: { fontSize: 14, color: '#444' },

  countsRow: { flexDirection: 'row', backgroundColor: '#f4f8ff', borderRadius: 14, padding: 16, marginBottom: 16, alignItems: 'center' },
  countBox: { flex: 1, alignItems: 'center' },
  countNumber: { fontSize: 26, fontWeight: '700', color: '#2D7CF6' },
  countLabel: { fontSize: 12, color: '#8E8E93', marginTop: 2 },
  countDivider: { width: 1, height: 40, backgroundColor: '#dde8ff' },

  tagsScroll: { marginBottom: 20 },
  vibeTag: { backgroundColor: '#e8f0ff', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6, marginRight: 8 },
  vibeTagText: { color: '#2D7CF6', fontSize: 13, fontWeight: '600' },

  button: { borderRadius: 14, height: 52, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  checkInButton: { backgroundColor: '#2D7CF6' },
  checkInButtonText: { color: '#fff', fontSize: 17, fontWeight: '700' },
  buttonDisabled: { backgroundColor: '#C7C7CC' },
  cancelButton: { borderWidth: 1.5, borderColor: '#FF3B30', backgroundColor: '#fff' },
  cancelButtonText: { color: '#FF3B30', fontSize: 15, fontWeight: '600' },
  peopleButton: { backgroundColor: '#f4f8ff', borderWidth: 1.5, borderColor: '#2D7CF6' },
  peopleButtonText: { color: '#2D7CF6', fontSize: 16, fontWeight: '700' },

  checkedInBadge: { backgroundColor: '#e6f9ec', borderRadius: 10, paddingVertical: 8, alignItems: 'center', marginBottom: 10 },
  checkedInBadgeText: { color: '#34C759', fontSize: 15, fontWeight: '700' },
});
