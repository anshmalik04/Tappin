import React, { useState, useEffect } from 'react';import {
View, Text, StyleSheet, TouchableOpacity, ScrollView, Switch, Image, ActivityIndicator,} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getProfile, updateProfile } from '../services/api';


export default function MeScreen({ navigation }) {
  const [ghostMode, setGhostMode] = useState(false);
  const [locationVisible, setLocationVisible] = useState(true);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await getProfile();
        setProfile(data);
      } catch (err) {
        console.warn('Profile fetch failed:', err.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color="#2D7CF6" />
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) return null;
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* ── Header ── */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>My Profile</Text>
        </View>

        {/* ── Profile card ── */}
        <View style={styles.profileCard}>
          <View style={styles.avatarContainer}>
            {profile.photo ? (
              <Image source={{ uri: profile.photo }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Text style={styles.avatarInitial}>
                  {profile.name.charAt(0).toUpperCase()}
                </Text>
              </View>
            )}
            <TouchableOpacity style={styles.editPhotoBtn}>
              <Text style={styles.editPhotoBtnText}>📷</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{profile.name}</Text>
            <Text style={styles.profileAge}>Age {profile.age}</Text>
            {profile.isPro && (
              <View style={styles.proBadge}>
                <Text style={styles.proBadgeText}>⚡ Pro</Text>
              </View>
            )}
          </View>
        </View>

        {/* ── Bio ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Bio</Text>
          <Text style={styles.bioText}>{profile.bio}</Text>
          <TouchableOpacity style={styles.editLink}>
            <Text style={styles.editLinkText}>Edit bio →</Text>
          </TouchableOpacity>
        </View>

        {/* ── Vibe tags ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Vibe</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {profile.tags.map(tag => (
              <View key={tag} style={styles.vibeTag}>
                <Text style={styles.vibeTagText}>{tag}</Text>
              </View>
            ))}
            <TouchableOpacity style={styles.addTagBtn}>
              <Text style={styles.addTagBtnText}>+ Add</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>

        {/* ── Pro banner ── */}
        {!profile.isPro && (
          <TouchableOpacity style={styles.proBanner} activeOpacity={0.85}>
            <View>
              <Text style={styles.proBannerTitle}>⚡ Upgrade to Tappin Pro</Text>
              <Text style={styles.proBannerSub}>
                Unlock People at Venue, unlimited Tap Ins, advanced filters & more
              </Text>
            </View>
            <Text style={styles.proBannerPrice}>$9.99/mo →</Text>
          </TouchableOpacity>
        )}

        {/* ── Privacy controls ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Privacy</Text>

          <View style={styles.toggleRow}>
            <View style={styles.toggleInfo}>
              <Text style={styles.toggleLabel}>👻 Ghost Mode</Text>
              <Text style={styles.toggleSub}>Hide yourself from the map</Text>
            </View>
            <Switch
              value={ghostMode}
              onValueChange={setGhostMode}
              trackColor={{ false: '#ddd', true: '#2D7CF6' }}
              thumbColor="#fff"
            />
          </View>

          <View style={styles.toggleRow}>
            <View style={styles.toggleInfo}>
              <Text style={styles.toggleLabel}>📍 Show My Location</Text>
              <Text style={styles.toggleSub}>Appear on the heatmap</Text>
            </View>
            <Switch
              value={locationVisible}
              onValueChange={setLocationVisible}
              trackColor={{ false: '#ddd', true: '#2D7CF6' }}
              thumbColor="#fff"
            />
          </View>
        </View>

        {/* ── Settings links ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>

          {[
            { icon: '🆘', label: 'Emergency Contacts' },
            { icon: '🔔', label: 'Notifications' },
            { icon: '🔒', label: 'Privacy & Data' },
            { icon: '❓', label: 'Help & Support' },
            { icon: '📄', label: 'Terms & Privacy Policy' },
          ].map(item => (
            <TouchableOpacity key={item.label} style={styles.settingsRow}>
              <Text style={styles.settingsIcon}>{item.icon}</Text>
              <Text style={styles.settingsLabel}>{item.label}</Text>
              <Text style={styles.settingsArrow}>›</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* ── Sign out ── */}
        <TouchableOpacity style={styles.signOutBtn}>
          <Text style={styles.signOutText}>Sign Out</Text>
        </TouchableOpacity>

        <View style={styles.bottomPad} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f8f8' },

  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 4 },
  headerTitle: { fontSize: 28, fontWeight: '800', color: '#1a1a1a' },

  profileCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#fff', marginHorizontal: 16, marginTop: 12,
    borderRadius: 16, padding: 16,
    shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 8, shadowOffset: { width: 0, height: 2 },
  },
  avatarContainer: { position: 'relative', marginRight: 16 },
  avatar: { width: 72, height: 72, borderRadius: 36 },
  avatarPlaceholder: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: '#2D7CF6', justifyContent: 'center', alignItems: 'center',
  },
  avatarInitial: { fontSize: 28, fontWeight: '700', color: '#fff' },
  editPhotoBtn: {
    position: 'absolute', bottom: 0, right: 0,
    backgroundColor: '#fff', borderRadius: 12, width: 24, height: 24,
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#000', shadowOpacity: 0.15, shadowRadius: 4,
  },
  editPhotoBtnText: { fontSize: 12 },
  profileInfo: { flex: 1 },
  profileName: { fontSize: 20, fontWeight: '700', color: '#1a1a1a', marginBottom: 2 },
  profileAge: { fontSize: 14, color: '#8E8E93', marginBottom: 6 },
  proBadge: { backgroundColor: '#fff3e0', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, alignSelf: 'flex-start' },
  proBadgeText: { fontSize: 12, fontWeight: '700', color: '#FF9500' },

  section: {
    backgroundColor: '#fff', marginHorizontal: 16, marginTop: 12,
    borderRadius: 16, padding: 16,
    shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, shadowOffset: { width: 0, height: 1 },
  },
  sectionTitle: { fontSize: 13, fontWeight: '700', color: '#8E8E93', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 },

  bioText: { fontSize: 15, color: '#333', lineHeight: 22, marginBottom: 8 },
  editLink: { alignSelf: 'flex-start' },
  editLinkText: { fontSize: 13, color: '#2D7CF6', fontWeight: '600' },

  vibeTag: { backgroundColor: '#e8f0ff', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6, marginRight: 8 },
  vibeTagText: { color: '#2D7CF6', fontSize: 13, fontWeight: '600' },
  addTagBtn: { backgroundColor: '#f0f0f0', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6, marginRight: 8 },
  addTagBtnText: { color: '#888', fontSize: 13, fontWeight: '600' },

  proBanner: {
    backgroundColor: '#1a1a1a', marginHorizontal: 16, marginTop: 12,
    borderRadius: 16, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  proBannerTitle: { fontSize: 15, fontWeight: '700', color: '#fff', marginBottom: 4 },
  proBannerSub: { fontSize: 12, color: '#aaa', maxWidth: 220, lineHeight: 17 },
  proBannerPrice: { fontSize: 14, fontWeight: '700', color: '#FFD60A' },

  toggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  toggleInfo: { flex: 1 },
  toggleLabel: { fontSize: 15, fontWeight: '600', color: '#1a1a1a', marginBottom: 2 },
  toggleSub: { fontSize: 12, color: '#8E8E93' },

  settingsRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  settingsIcon: { fontSize: 18, marginRight: 12 },
  settingsLabel: { flex: 1, fontSize: 15, color: '#1a1a1a' },
  settingsArrow: { fontSize: 20, color: '#C7C7CC' },

  signOutBtn: { marginHorizontal: 16, marginTop: 16, padding: 16, backgroundColor: '#fff', borderRadius: 16, alignItems: 'center' },
  signOutText: { fontSize: 15, fontWeight: '600', color: '#FF3B30' },
  bottomPad: { height: 40 },
});
