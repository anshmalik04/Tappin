import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, Image, ScrollView
} from 'react-native';

const MOCK_MATCHES = [
  {
    id: '1',
    name: 'Sarah M.',
    photo: 'https://picsum.photos/100/100?random=1',
    venue: "McGillin's Olde Ale House",
    lastMessage: 'Meet me at: Main floor',
    timestamp: '11:54 PM',
    unread: true,
  },
  {
    id: '2',
    name: 'Jordan K.',
    photo: 'https://picsum.photos/100/100?random=2',
    venue: 'The Concourse',
    lastMessage: 'Hey! Where are you?',
    timestamp: '11:30 PM',
    unread: true,
  },
  {
    id: '3',
    name: 'Alex R.',
    photo: 'https://picsum.photos/100/100?random=3',
    venue: 'Recess',
    lastMessage: 'That was so fun tonight 🔥',
    timestamp: '10:45 PM',
    unread: false,
  },
];

const MOCK_TAPPED_IN_ON_ME = [
  { id: '4', name: 'Maya L.', photo: 'https://picsum.photos/100/100?random=4' },
  { id: '5', name: 'Chris T.', photo: 'https://picsum.photos/100/100?random=5' },
  { id: '6', name: 'Dana W.', photo: 'https://picsum.photos/100/100?random=6' },
];

const MOCK_IS_PRO = false;

export default function MatchesScreen({ navigation }) {
  const [matches, setMatches] = useState(MOCK_MATCHES);

  const renderMatch = ({ item }) => (
    <TouchableOpacity
      style={styles.matchRow}
      onPress={() => navigation.navigate('Chat')}
    >
      <View style={styles.photoContainer}>
        <Image source={{ uri: item.photo }} style={styles.photo} />
        {item.unread && <View style={styles.unreadDot} />}
      </View>
      <View style={styles.matchInfo}>
        <View style={styles.matchTopRow}>
          <Text style={styles.matchName}>{item.name}</Text>
          <Text style={styles.matchTimestamp}>{item.timestamp}</Text>
        </View>
        <Text style={styles.matchVenue}>📍 {item.venue}</Text>
        <Text
          style={[styles.matchLastMessage, item.unread && styles.matchLastMessageUnread]}
          numberOfLines={1}
        >
          {item.lastMessage}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Matches</Text>
      </View>

      {/* Pro: Tapped In on you */}
      {MOCK_IS_PRO ? (
        <View style={styles.tappedInSection}>
          <Text style={styles.tappedInHeading}>
            {MOCK_TAPPED_IN_ON_ME.length} people Tapped In on you
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {MOCK_TAPPED_IN_ON_ME.map(user => (
              <TouchableOpacity key={user.id} style={styles.tappedInUser}>
                <Image source={{ uri: user.photo }} style={styles.tappedInPhoto} />
                <Text style={styles.tappedInName}>{user.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      ) : (
        <TouchableOpacity style={styles.proPrompt}>
          <Text style={styles.proPromptText}>
            🔒 {MOCK_TAPPED_IN_ON_ME.length} people Tapped In on you —{' '}
            <Text style={styles.proPromptLink}>Upgrade to Pro to see</Text>
          </Text>
        </TouchableOpacity>
      )}

      {/* Matches list */}
      {matches.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>No matches yet.</Text>
          <Text style={styles.emptyStateSubtext}>
            Check in to a venue and Tap In on someone.
          </Text>
        </View>
      ) : (
        <FlatList
          data={matches}
          keyExtractor={item => item.id}
          renderItem={renderMatch}
          contentContainerStyle={styles.list}
        />
      )}

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: {
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: { fontSize: 28, fontWeight: '800', color: '#111' },
  tappedInSection: {
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  tappedInHeading: {
    fontSize: 13,
    fontWeight: '600',
    color: '#888',
    marginBottom: 12,
    textTransform: 'uppercase',
  },
  tappedInUser: { alignItems: 'center', marginRight: 16 },
  tappedInPhoto: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: '#2563eb',
  },
  tappedInName: { fontSize: 11, color: '#444', marginTop: 4 },
  proPrompt: {
    backgroundColor: '#eff6ff',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#dbeafe',
  },
  proPromptText: { fontSize: 13, color: '#444' },
  proPromptLink: { color: '#2563eb', fontWeight: '700' },
  list: { paddingVertical: 8 },
  matchRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    alignItems: 'center',
  },
  photoContainer: { position: 'relative', marginRight: 14 },
  photo: { width: 56, height: 56, borderRadius: 28 },
  unreadDot: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#2563eb',
    borderWidth: 2,
    borderColor: '#fff',
  },
  matchInfo: { flex: 1 },
  matchTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  matchName: { fontSize: 16, fontWeight: '700', color: '#111' },
  matchTimestamp: { fontSize: 12, color: '#aaa' },
  matchVenue: { fontSize: 12, color: '#888', marginBottom: 3 },
  matchLastMessage: { fontSize: 14, color: '#888' },
  matchLastMessageUnread: { color: '#111', fontWeight: '600' },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#888',
    textAlign: 'center',
    lineHeight: 20,
  },
});