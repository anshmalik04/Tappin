import React, { useState, useCallback, useEffect } from 'react';import {
  View, Text, StyleSheet, TouchableOpacity, FlatList,
  RefreshControl, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getHeatmapData } from '../services/api';



const FILTERS = ['All', 'Bars', 'Clubs', 'Events', 'Free Entry'];

function getHeatDotColor(score) {
  if (score > 70) return '#FF3B30';
  if (score > 40) return '#FF9500';
  if (score > 15) return '#8E8E93';
  return '#C7C7CC';
}

function getHeatLabel(score) {
  if (score > 70) return 'Hot';
  if (score > 40) return 'Warm';
  if (score > 15) return 'Mild';
  return 'Quiet';
}

export default function TonightScreen({ navigation }) {
  const [filter, setFilter] = useState('All');
  const [refreshing, setRefreshing] = useState(false);
const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const loadVenues = useCallback(async () => {
    try {
      const data = await getHeatmapData();
      setVenues(data.venues || []);
    } catch (err) {
      console.warn('Tonight fetch failed:', err.message);
      setVenues([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadVenues();
  }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadVenues();
  }, [loadVenues]);

  const filteredVenues = venues.filter(v => {
    if (filter === 'All') return true;
    if (filter === 'Bars') return v.type === 'Bar';
    if (filter === 'Clubs') return v.type === 'Club';
    if (filter === 'Free Entry') return v.cover === 'Free';
    return true;
  });

  const renderVenue = ({ item, index }) => {
    const dotColor = getHeatDotColor(item.score);
    const heatLabel = getHeatLabel(item.score);

    return (
      <TouchableOpacity
        style={styles.venueRow}
        onPress={() => navigation.navigate('VenueCard', { venueId: item.id })}
        activeOpacity={0.75}
      >
        {/* Rank number */}
        <Text style={styles.rank}>#{index + 1}</Text>

        {/* Main content */}
        <View style={styles.venueInfo}>
          <View style={styles.venueNameRow}>
            <Text style={styles.venueName}>{item.name}</Text>
            <View style={[styles.heatDot, { backgroundColor: dotColor }]} />
          </View>

          <Text style={styles.neighborhood}>{item.neighborhood} · {item.hours}</Text>

          {/* Tags */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tagsRow}>
            {item.tags.map(tag => (
              <View key={tag} style={styles.tag}>
                <Text style={styles.tagText}>{tag}</Text>
              </View>
            ))}
          </ScrollView>

          {/* Stats row */}
          <View style={styles.statsRow}>
            <Text style={styles.stat}>👥 {item.arrived} here</Text>
            <Text style={styles.statDivider}>·</Text>
            <Text style={styles.stat}>📍 {item.going} going</Text>
            <Text style={styles.statDivider}>·</Text>
            <Text style={styles.stat}>🎟 {item.cover}</Text>
          </View>
        </View>

        {/* Heat label */}
        <View style={[styles.heatBadge, { borderColor: dotColor }]}>
          <Text style={[styles.heatBadgeText, { color: dotColor }]}>{heatLabel}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Tonight</Text>
        <Text style={styles.headerSub}>Philadelphia · {filteredVenues.length} venues</Text>
      </View>

      {/* Filter chips */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterRow}
        contentContainerStyle={styles.filterContent}
      >
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, filter === f && styles.filterChipActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Venue list */}
      {filteredVenues.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🌙</Text>
          <Text style={styles.emptyTitle}>No venues yet</Text>
          <Text style={styles.emptySub}>Check back later or change your filter.</Text>
        </View>
      ) : (
        <FlatList
          data={filteredVenues}
          keyExtractor={item => item.id}
          renderItem={renderVenue}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#2D7CF6" />
          }
          ItemSeparatorComponent={() => <View style={styles.separator} />}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },

  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 12 },
  headerTitle: { fontSize: 28, fontWeight: '800', color: '#1a1a1a' },
  headerSub: { fontSize: 13, color: '#8E8E93', marginTop: 2 },

  filterRow: { paddingBottom: 12 },
  filterContent: { paddingHorizontal: 16, gap: 8 },
  filterChip: {
    backgroundColor: '#fff', borderRadius: 20, paddingHorizontal: 16, paddingVertical: 7,
    borderWidth: 1.5, borderColor: '#ddd',
  },
  filterChipActive: { backgroundColor: '#2D7CF6', borderColor: '#2D7CF6' },
  filterText: { fontSize: 13, fontWeight: '600', color: '#555' },
  filterTextActive: { color: '#fff' },

  listContent: { paddingHorizontal: 16, paddingBottom: 32 },
  separator: { height: 1, backgroundColor: '#f0f0f0', marginVertical: 4 },

  venueRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: 14, gap: 12,
  },
  rank: { fontSize: 18, fontWeight: '800', color: '#C7C7CC', width: 28, textAlign: 'center' },

  venueInfo: { flex: 1 },
  venueNameRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 3 },
  venueName: { fontSize: 16, fontWeight: '700', color: '#1a1a1a', flex: 1, marginRight: 8 },
  heatDot: { width: 10, height: 10, borderRadius: 5 },
  neighborhood: { fontSize: 12, color: '#8E8E93', marginBottom: 6 },

  tagsRow: { marginBottom: 6 },
  tag: { backgroundColor: '#f0f4ff', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 3, marginRight: 6 },
  tagText: { fontSize: 11, color: '#2D7CF6', fontWeight: '600' },

  statsRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  stat: { fontSize: 12, color: '#555' },
  statDivider: { fontSize: 12, color: '#C7C7CC' },

  heatBadge: {
    borderWidth: 1.5, borderRadius: 10,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  heatBadgeText: { fontSize: 11, fontWeight: '700' },

  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingBottom: 80 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a1a', marginBottom: 6 },
  emptySub: { fontSize: 14, color: '#8E8E93', textAlign: 'center' },
});
