export const config = {
  region: 'us-east-1',
  userPoolId: 'us-east-1_bLzA6w9vl',
  userPoolClientId: '7knjcs2alfcc9pk6sbj57mffhk',
  redirectUri: 'tappin://callback',
  apiBaseUrl: 'https://lftvm17k0f.execute-api.us-east-1.amazonaws.com',
  wsUrl: 'wss://lfcdr0kcn9.execute-api.us-east-1.amazonaws.com/production',
  s3Bucket: 'tappin-photos',
};
